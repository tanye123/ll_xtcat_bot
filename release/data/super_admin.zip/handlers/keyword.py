"""
禁词系统处理器
"""
from typing import TYPE_CHECKING, Optional, List, Dict
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from core.api import API


class KeywordHandler:
    """禁词系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission
        # 违规次数 {group_id: {user_id: count}}
        self._violation_count: Dict[int, Dict[int, int]] = {}

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理禁词系统配置命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 数值设置
        if text.startswith("禁词禁言时间 "):
            rest = text[7:].strip()
            if rest.isdigit():
                value = int(rest)
                if 1 <= value <= 999:
                    self.config.set_value(group_id, "禁词禁言时间", value)
                    return f"已设置禁词禁言时间为 {value} 分钟"

        if text.startswith("禁词踢人机会 "):
            rest = text[7:].strip()
            if rest.isdigit():
                value = int(rest)
                if 1 <= value <= 99:
                    self.config.set_value(group_id, "禁词踢人机会", value)
                    return f"已设置禁词踢人机会为 {value} 次"

        # 关键词列表操作
        keyword_lists = {
            "禁言关键词": "禁言词",
            "撤回关键词": "撤回词",
            "踢人关键词": "踢人词",
        }

        for cmd_name, list_name in keyword_lists.items():
            # 加xxx 内容
            if text.startswith(f"加{cmd_name} "):
                content = text[len(f"加{cmd_name} "):].strip()
                if content:
                    self.config.add_to_list(group_id, list_name, content)
                    return f"已添加{cmd_name}: {content}"

            # 删xxx 内容
            if text.startswith(f"删{cmd_name} "):
                content = text[len(f"删{cmd_name} "):].strip()
                if content:
                    self.config.remove_from_list(group_id, list_name, content)
                    return f"已删除{cmd_name}: {content}"

        # 查看/清空列表
        list_views = {
            "禁言词": "禁言词列表",
            "撤回词": "撤回词列表",
            "踢人词": "踢人词列表",
        }

        for list_name, display_name in list_views.items():
            if text == f"查看{display_name}":
                items = self.config.get_list(group_id, list_name)
                if not items:
                    return f"{display_name}为空"
                return f"{display_name}:\n" + "\n".join(items)

            if text == f"清空{display_name}":
                self.config.clear_list(group_id, list_name)
                return f"已清空{display_name}"

        return None

    async def check_keyword(self, group_id: int, user_id: int, text: str, message_id: int, api: "API") -> Optional[str]:
        """
        检查消息是否包含禁词

        Returns:
            处理结果或 None
        """
        # 检查白名单
        if self.permission.is_in_whitelist(group_id, user_id):
            return None

        # 检查管理员
        if self.permission.is_group_admin(group_id, user_id):
            return None

        result = None

        # 检查撤回词
        if self.config.get_switch(group_id, "关键词撤回"):
            recall_words = self.config.get_list(group_id, "撤回词")
            for word in recall_words:
                if word in text:
                    try:
                        await api.delete_msg(message_id)
                        if self.config.get_switch(group_id, "关键词撤回提示"):
                            result = f"消息包含禁词，已撤回"
                    except Exception:
                        pass
                    break

        # 检查禁言词
        if self.config.get_switch(group_id, "关键词禁言"):
            ban_words = self.config.get_list(group_id, "禁言词")
            for word in ban_words:
                if word in text:
                    duration = self.config.get_value(group_id, "禁词禁言时间")
                    await api.set_group_ban(group_id, user_id, duration * 60)
                    if self.config.get_switch(group_id, "关键词禁言提示"):
                        result = f"消息包含禁词，已禁言 {duration} 分钟"
                    break

        # 检查踢人词
        if self.config.get_switch(group_id, "关键词踢人"):
            kick_words = self.config.get_list(group_id, "踢人词")
            for word in kick_words:
                if word in text:
                    # 记录违规次数
                    if group_id not in self._violation_count:
                        self._violation_count[group_id] = {}
                    if user_id not in self._violation_count[group_id]:
                        self._violation_count[group_id][user_id] = 0

                    self._violation_count[group_id][user_id] += 1
                    max_chances = self.config.get_value(group_id, "禁词踢人机会")

                    if self._violation_count[group_id][user_id] >= max_chances:
                        await api.set_group_kick(group_id, user_id, False)
                        del self._violation_count[group_id][user_id]
                        if self.config.get_switch(group_id, "关键词踢人提示"):
                            result = "违规次数过多，已踢出群聊"
                    else:
                        remaining = max_chances - self._violation_count[group_id][user_id]
                        if self.config.get_switch(group_id, "关键词踢人提示"):
                            result = f"消息包含禁词！还有 {remaining} 次机会"
                    break

        return result
