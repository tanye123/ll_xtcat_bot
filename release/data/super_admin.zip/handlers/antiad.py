"""
广告杀手处理器
"""
import re
from typing import TYPE_CHECKING, Optional, List

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from core.api import API


class AntiAdHandler:
    """广告杀手处理器"""

    # 消息类型检测规则
    MESSAGE_TYPES = {
        "撤回图片": r"\[CQ:image,",
        "撤回表情": r"\[CQ:face,",
        "撤回语音": r"\[CQ:record,",
        "撤回视频": r"\[CQ:video,",
        "撤回转发": r"\[CQ:forward,",
        "撤回闪照": r"type=flash",
        "撤回卡片": r"\[CQ:json,|\[CQ:xml,",
        "撤回涂鸦": r"\[CQ:poke,",
    }

    # 文本内容检测规则
    TEXT_PATTERNS = {
        "撤回号码": r"\d{5,}",  # 5位以上数字
        "撤回链接": r"https?://|www\.",  # URL
        "撤回群链": r"qun\.qq\.com|group\.qq\.com",  # 群链接
    }

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    async def check_message(self, group_id: int, user_id: int, raw_message: str, message_id: int, api: "API") -> Optional[str]:
        """
        检查消息是否需要撤回

        Returns:
            撤回原因或 None
        """
        # 检查白名单
        if self.permission.is_in_whitelist(group_id, user_id):
            return None

        # 检查管理员
        if self.permission.is_group_admin(group_id, user_id):
            return None

        # 检查消息类型
        for switch_name, pattern in self.MESSAGE_TYPES.items():
            if self.config.get_switch(group_id, switch_name):
                if re.search(pattern, raw_message):
                    await api.delete_msg(message_id)
                    return switch_name.replace("撤回", "")

        # 检查文本内容
        for switch_name, pattern in self.TEXT_PATTERNS.items():
            if self.config.get_switch(group_id, switch_name):
                if re.search(pattern, raw_message):
                    await api.delete_msg(message_id)
                    return switch_name.replace("撤回", "")

        # 检查匿名消息
        if self.config.get_switch(group_id, "撤回匿名"):
            if "[CQ:anonymous" in raw_message or user_id == 80000000:
                await api.delete_msg(message_id)
                return "匿名消息"

        return None
