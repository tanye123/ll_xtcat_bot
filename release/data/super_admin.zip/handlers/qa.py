"""
问答系统处理器
"""
import re
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class QAHandler:
    """问答系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理问答系统配置命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 精准问xxx答xxx
        match = re.match(r"^精准问(.+)答(.+)$", text)
        if match:
            question = match.group(1)
            answer = match.group(2)
            self.config.add_qa(group_id, "精准", question, answer)
            return f"已添加精准问答: {question} -> {answer}"

        # 模糊问xxx答xxx
        match = re.match(r"^模糊问(.+)答(.+)$", text)
        if match:
            question = match.group(1)
            answer = match.group(2)
            self.config.add_qa(group_id, "模糊", question, answer)
            return f"已添加模糊问答: {question} -> {answer}"

        # 精准问xxx私xxx
        match = re.match(r"^精准问(.+)私(.+)$", text)
        if match:
            question = match.group(1)
            answer = f"[私聊]{match.group(2)}"
            self.config.add_qa(group_id, "精准", question, answer)
            return f"已添加精准私聊问答: {question}"

        # 模糊问xxx私xxx
        match = re.match(r"^模糊问(.+)私(.+)$", text)
        if match:
            question = match.group(1)
            answer = f"[私聊]{match.group(2)}"
            self.config.add_qa(group_id, "模糊", question, answer)
            return f"已添加模糊私聊问答: {question}"

        # 删精准 xxx
        if text.startswith("删精准 "):
            question = text[4:].strip()
            self.config.remove_qa(group_id, "精准", question)
            return f"已删除精准问答: {question}"

        # 删模糊 xxx
        if text.startswith("删模糊 "):
            question = text[4:].strip()
            self.config.remove_qa(group_id, "模糊", question)
            return f"已删除模糊问答: {question}"

        # 查看精准问词库
        if text == "查看精准问词库":
            qa = self.config.get_qa(group_id)
            exact = qa.get("精准", {})
            if not exact:
                return "精准问词库为空"
            lines = ["精准问词库:"]
            for q, a in list(exact.items())[:20]:
                lines.append(f"问: {q}")
                lines.append(f"答: {a[:50]}...")
            return "\n".join(lines)

        # 清空精准问词库
        if text == "清空精准问词库":
            self.config.clear_qa(group_id, "精准")
            return "已清空精准问词库"

        # 查看模糊问词库
        if text == "查看模糊问词库":
            qa = self.config.get_qa(group_id)
            fuzzy = qa.get("模糊", {})
            if not fuzzy:
                return "模糊问词库为空"
            lines = ["模糊问词库:"]
            for q, a in list(fuzzy.items())[:20]:
                lines.append(f"问: {q}")
                lines.append(f"答: {a[:50]}...")
            return "\n".join(lines)

        # 清空模糊问词库
        if text == "清空模糊问词库":
            self.config.clear_qa(group_id, "模糊")
            return "已清空模糊问词库"

        return None

    def check_qa(self, group_id: int, text: str) -> Optional[dict]:
        """
        检查是否匹配问答

        Returns:
            {"answer": str, "private": bool} 或 None
        """
        # 检查问答功能是否开启
        if not self.config.get_switch(group_id, "问答"):
            return None

        qa = self.config.get_qa(group_id)

        # 精准匹配
        exact = qa.get("精准", {})
        if text in exact:
            answer = exact[text]
            private = answer.startswith("[私聊]")
            if private:
                answer = answer[4:]
            return {"answer": answer, "private": private}

        # 模糊匹配
        fuzzy = qa.get("模糊", {})
        for keyword, answer in fuzzy.items():
            if keyword in text:
                private = answer.startswith("[私聊]")
                if private:
                    answer = answer[4:]
                return {"answer": answer, "private": private}

        return None
