"""
统计系统处理器
"""
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Optional, List
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class StatsHandler:
    """统计系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def parse_at(self, text: str) -> List[int]:
        """解析 @ 的用户"""
        pattern = r"\[CQ:at,qq=(\d+)[^\]]*\]"
        matches = re.findall(pattern, text)
        return [int(qq) for qq in matches]

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理统计命令"""
        text = text.strip()

        # 邀请统计
        if text == "邀请统计":
            if not self.permission.is_group_admin(group_id, user_id, event):
                return "权限不足"
            return self._get_invite_stats(group_id)

        # 发言统计
        if text == "发言统计":
            if not self.permission.is_group_admin(group_id, user_id, event):
                return "权限不足"
            return self._get_message_stats(group_id)

        # 查邀请@某人
        if text.startswith("查邀请"):
            targets = self.parse_at(text)
            if targets:
                return self._get_user_invite_stats(group_id, targets[0])
            # 查邀请 QQ号
            rest = text[3:].strip()
            if rest.isdigit():
                return self._get_user_invite_stats(group_id, int(rest))

        # 查发言@某人
        if text.startswith("查发言"):
            targets = self.parse_at(text)
            if targets:
                return self._get_user_message_stats(group_id, targets[0])
            # 查发言 QQ号
            rest = text[3:].strip()
            if rest.isdigit():
                return self._get_user_message_stats(group_id, int(rest))

        return None

    def _get_invite_stats(self, group_id: int) -> str:
        """获取邀请统计"""
        stats = self.config.get_stats(group_id)
        invites = stats.get("invites", {})

        if not invites:
            return "暂无邀请记录"

        # 按邀请数量排序
        sorted_invites = sorted(invites.items(), key=lambda x: len(x[1]), reverse=True)

        lines = ["邀请统计", "╭───────────╮"]
        for i, (uid, invited_list) in enumerate(sorted_invites[:10], 1):
            user_data = self.config.get_user_data(group_id, int(uid))
            nickname = user_data.get("nickname", uid)
            lines.append(f"┣{i}. {nickname}: {len(invited_list)}人")
        lines.append("╰───────────╯")

        return "\n".join(lines)

    def _get_message_stats(self, group_id: int) -> str:
        """获取发言统计"""
        stats = self.config.get_stats(group_id)
        messages = stats.get("messages", {})

        if not messages:
            return "暂无发言记录"

        today = datetime.now().strftime("%Y-%m-%d")

        # 统计今日发言
        today_stats = {}
        for uid, dates in messages.items():
            if today in dates:
                today_stats[uid] = dates[today]

        if not today_stats:
            return "今日暂无发言记录"

        # 按发言数量排序
        sorted_stats = sorted(today_stats.items(), key=lambda x: x[1], reverse=True)

        lines = ["今日发言统计", "╭───────────╮"]
        for i, (uid, count) in enumerate(sorted_stats[:10], 1):
            user_data = self.config.get_user_data(group_id, int(uid))
            nickname = user_data.get("nickname", uid)
            lines.append(f"┣{i}. {nickname}: {count}条")
        lines.append("╰───────────╯")

        return "\n".join(lines)

    def _get_user_invite_stats(self, group_id: int, target_id: int) -> str:
        """获取用户邀请统计"""
        stats = self.config.get_stats(group_id)
        invites = stats.get("invites", {})
        user_invites = invites.get(str(target_id), [])

        user_data = self.config.get_user_data(group_id, target_id)
        nickname = user_data.get("nickname", str(target_id))

        return f"【{nickname}】共邀请了 {len(user_invites)} 人"

    def _get_user_message_stats(self, group_id: int, target_id: int) -> str:
        """获取用户发言统计"""
        stats = self.config.get_stats(group_id)
        messages = stats.get("messages", {})
        user_messages = messages.get(str(target_id), {})

        user_data = self.config.get_user_data(group_id, target_id)
        nickname = user_data.get("nickname", str(target_id))

        today = datetime.now().strftime("%Y-%m-%d")
        today_count = user_messages.get(today, 0)
        total_count = sum(user_messages.values())

        return f"""【{nickname}】发言统计
╭───────────╮
┣今日发言: {today_count}条
┣总计发言: {total_count}条
╰───────────╯"""

    def record_message(self, group_id: int, user_id: int, nickname: str = ""):
        """记录发言"""
        self.config.record_message(group_id, user_id)
        if nickname:
            user_data = self.config.get_user_data(group_id, user_id)
            user_data["nickname"] = nickname
            user_data["stats"]["messages"] = user_data["stats"].get("messages", 0) + 1
            self.config.set_user_data(group_id, user_id, user_data)

    def record_invite(self, group_id: int, inviter_id: int, invited_id: int):
        """记录邀请"""
        self.config.record_invite(group_id, inviter_id, invited_id)
        user_data = self.config.get_user_data(group_id, inviter_id)
        user_data["stats"]["invites"] = user_data["stats"].get("invites", 0) + 1
        self.config.set_user_data(group_id, inviter_id, user_data)
