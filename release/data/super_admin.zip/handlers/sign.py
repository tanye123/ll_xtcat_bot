"""
签到系统处理器
"""
from datetime import datetime
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class SignHandler:
    """签到系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def is_sign_command(self, text: str) -> bool:
        """检查是否为签到命令"""
        text = text.strip()
        return text in ("签到", "打卡")

    def handle(self, group_id: int, user_id: int, text: str, nickname: str = "", event=None) -> Optional[str]:
        """处理签到命令"""
        text = text.strip()

        if text not in ("签到", "打卡"):
            return None

        # 检查签到功能是否开启
        if not self.config.get_switch(group_id, "签到"):
            return None

        # 获取用户数据
        user_data = self.config.get_user_data(group_id, user_id)
        sign_data = user_data.get("sign", {
            "total_days": 0,
            "continuous_days": 0,
            "last_sign": "",
        })

        today = datetime.now().strftime("%Y-%m-%d")
        last_sign = sign_data.get("last_sign", "")

        # 检查是否已签到
        if last_sign == today:
            return f"【{nickname or user_id}】今天已经签到过了哦~"

        # 计算连签
        yesterday = (datetime.now().replace(day=datetime.now().day - 1)).strftime("%Y-%m-%d") if datetime.now().day > 1 else ""
        if last_sign == yesterday:
            sign_data["continuous_days"] = sign_data.get("continuous_days", 0) + 1
        else:
            sign_data["continuous_days"] = 1

        sign_data["total_days"] = sign_data.get("total_days", 0) + 1
        sign_data["last_sign"] = today

        # 计算奖励
        base_reward = self.config.get_value(group_id, "签到奖励")
        continuous_reward = self.config.get_value(group_id, "连签奖励")
        total_reward = base_reward + (sign_data["continuous_days"] - 1) * continuous_reward

        # 更新用户数据
        user_data["sign"] = sign_data
        user_data["points"] = user_data.get("points", 0) + total_reward
        if nickname:
            user_data["nickname"] = nickname
        self.config.set_user_data(group_id, user_id, user_data)

        return f"""【{nickname or user_id}】签到成功！
╭───────────╮
┣累计签到: {sign_data['total_days']}天
┣连续签到: {sign_data['continuous_days']}天
┣获得积分: +{total_reward}
┣当前积分: {user_data['points']}
╰───────────╯"""

    def handle_config(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理签到配置命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 签到奖励设置
        if text.startswith("签到奖励"):
            rest = text[4:].strip()
            if rest.isdigit():
                value = int(rest)
                if 10 <= value <= 999:
                    self.config.set_value(group_id, "签到奖励", value)
                    return f"已设置签到奖励为 {value} 积分"
                else:
                    return "签到奖励范围: 10~999"

        # 连签奖励设置
        if text.startswith("连签奖励"):
            rest = text[4:].strip()
            if rest.isdigit():
                value = int(rest)
                if 10 <= value <= 999:
                    self.config.set_value(group_id, "连签奖励", value)
                    return f"已设置连签奖励为 {value} 积分"
                else:
                    return "连签奖励范围: 10~999"

        return None
