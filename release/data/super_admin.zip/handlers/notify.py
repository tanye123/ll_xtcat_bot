"""
提醒系统处理器
"""
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class NotifyHandler:
    """提醒系统处理器"""

    # 提醒类型配置
    NOTIFY_TYPES = {
        "退群提示": "退群提示",
        "被踢提示": "被踢提示",
        "上管提示": "上管提示",
        "下管提示": "下管提示",
    }

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理提醒系统命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 查看提示系统变量
        if text == "查看提示系统变量":
            return """提示系统变量说明
╭───────────╮
┣{nickname} - 昵称
┣{user_id} - QQ号
┣{group_id} - 群号
┣{date} - 日期
┣{time} - 时间
╰───────────╯"""

        # 设置提示内容
        for notify_type, config_key in self.NOTIFY_TYPES.items():
            if text.startswith(f"{notify_type} "):
                content = text[len(notify_type) + 1:].strip()
                if content:
                    self.config.set_text(group_id, config_key, content)
                    return f"已设置{notify_type}内容"

        return None

    def get_notify_message(self, group_id: int, notify_type: str, variables: dict) -> Optional[str]:
        """获取提醒消息"""
        # 检查开关
        if not self.config.get_switch(group_id, notify_type):
            return None

        # 获取模板
        template = self.config.get_text(group_id, notify_type)
        if not template:
            return None

        # 替换变量
        for key, value in variables.items():
            template = template.replace(f"{{{key}}}", str(value))

        return template
