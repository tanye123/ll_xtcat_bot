"""
银行系统处理器
"""
import random
from typing import TYPE_CHECKING, Optional, List
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class BankHandler:
    """银行系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def parse_at(self, text: str) -> List[int]:
        """解析 @ 的用户"""
        pattern = r"\[CQ:at,qq=(\d+)[^\]]*\]"
        matches = re.findall(pattern, text)
        return [int(qq) for qq in matches]

    def handle(self, group_id: int, user_id: int, text: str, nickname: str = "", event=None) -> Optional[str]:
        """处理银行系统命令"""
        text = text.strip()

        # 检查银行功能是否开启
        if not self.config.get_switch(group_id, "银行"):
            return None

        # 我的积分
        if text == "我的积分":
            user_data = self.config.get_user_data(group_id, user_id)
            points = user_data.get("points", 0)
            bank = user_data.get("bank", 0)
            loan = user_data.get("loan", 0)
            return f"""【{nickname or user_id}】的积分
╭───────────╮
┣现金: {points}
┣存款: {bank}
┣贷款: {loan}
┣总资产: {points + bank - loan}
╰───────────╯"""

        # 存款 积分
        if text.startswith("存款 "):
            rest = text[3:].strip()
            if rest.isdigit():
                amount = int(rest)
                user_data = self.config.get_user_data(group_id, user_id)
                points = user_data.get("points", 0)

                if amount > points:
                    return "积分不足"

                user_data["points"] = points - amount
                user_data["bank"] = user_data.get("bank", 0) + amount
                self.config.set_user_data(group_id, user_id, user_data)
                return f"已存入 {amount} 积分，当前存款: {user_data['bank']}"

        # 取款 积分
        if text.startswith("取款 "):
            rest = text[3:].strip()
            if rest.isdigit():
                amount = int(rest)
                user_data = self.config.get_user_data(group_id, user_id)
                bank = user_data.get("bank", 0)

                if amount > bank:
                    return "存款不足"

                # 计算利润
                profit_rate = self.config.get_value(group_id, "银行利润") / 100
                profit = int(amount * profit_rate)

                user_data["bank"] = bank - amount
                user_data["points"] = user_data.get("points", 0) + amount + profit
                self.config.set_user_data(group_id, user_id, user_data)
                return f"已取出 {amount} 积分，利润 {profit}，当前存款: {user_data['bank']}"

        # 贷款 积分
        if text.startswith("贷款 "):
            rest = text[3:].strip()
            if rest.isdigit():
                amount = int(rest)
                user_data = self.config.get_user_data(group_id, user_id)
                loan = user_data.get("loan", 0)

                if loan > 0:
                    return f"你还有 {loan} 积分贷款未还清"

                user_data["loan"] = amount
                user_data["points"] = user_data.get("points", 0) + amount
                self.config.set_user_data(group_id, user_id, user_data)
                return f"已贷款 {amount} 积分"

        # 还款 积分
        if text.startswith("还款 "):
            rest = text[3:].strip()
            if rest.isdigit():
                amount = int(rest)
                user_data = self.config.get_user_data(group_id, user_id)
                loan = user_data.get("loan", 0)
                points = user_data.get("points", 0)

                if loan == 0:
                    return "你没有贷款"

                # 计算利息
                interest_rate = self.config.get_value(group_id, "银行利息") / 100
                interest = int(amount * interest_rate)
                total = amount + interest

                if total > points:
                    return f"积分不足，需要 {total} 积分（含利息 {interest}）"

                repay = min(amount, loan)
                user_data["loan"] = loan - repay
                user_data["points"] = points - repay - interest
                self.config.set_user_data(group_id, user_id, user_data)
                return f"已还款 {repay} 积分，利息 {interest}，剩余贷款: {user_data['loan']}"

        # 转账@某人 积分
        if text.startswith("转账"):
            if not self.config.get_switch(group_id, "转账"):
                return "转账功能已关闭"

            targets = self.parse_at(text)
            if targets:
                rest = re.sub(r"\[CQ:at,qq=\d+[^\]]*\]", "", text[2:]).strip()
                if rest.isdigit():
                    amount = int(rest)
                    target = targets[0]

                    user_data = self.config.get_user_data(group_id, user_id)
                    points = user_data.get("points", 0)

                    if amount > points:
                        return "积分不足"

                    # 扣除转账者积分
                    user_data["points"] = points - amount
                    self.config.set_user_data(group_id, user_id, user_data)

                    # 增加接收者积分
                    target_data = self.config.get_user_data(group_id, target)
                    target_data["points"] = target_data.get("points", 0) + amount
                    self.config.set_user_data(group_id, target, target_data)

                    return f"已转账 {amount} 积分给对方"

        # 打劫@某人
        if text.startswith("打劫"):
            if not self.config.get_switch(group_id, "打劫"):
                return "打劫功能已关闭"

            targets = self.parse_at(text)
            if targets:
                target = targets[0]
                target_data = self.config.get_user_data(group_id, target)
                target_points = target_data.get("points", 0)

                if target_points < 100:
                    return "对方积分太少，不值得打劫"

                # 50% 成功率
                if random.random() < 0.5:
                    rob_amount = random.randint(1, min(target_points // 2, 500))
                    target_data["points"] = target_points - rob_amount
                    self.config.set_user_data(group_id, target, target_data)

                    user_data = self.config.get_user_data(group_id, user_id)
                    user_data["points"] = user_data.get("points", 0) + rob_amount
                    self.config.set_user_data(group_id, user_id, user_data)

                    return f"打劫成功！获得 {rob_amount} 积分"
                else:
                    # 失败，扣除自己积分
                    user_data = self.config.get_user_data(group_id, user_id)
                    penalty = min(user_data.get("points", 0), 100)
                    user_data["points"] = user_data.get("points", 0) - penalty
                    self.config.set_user_data(group_id, user_id, user_data)
                    return f"打劫失败！被罚款 {penalty} 积分"

        # 加/减积分@某人 积分（管理员命令）
        if text.startswith("加积分") or text.startswith("减积分"):
            if not self.permission.is_group_admin(group_id, user_id, event):
                return None

            is_add = text.startswith("加积分")
            targets = self.parse_at(text)
            if targets:
                rest = re.sub(r"\[CQ:at,qq=\d+[^\]]*\]", "", text[3:]).strip()
                if rest.isdigit():
                    amount = int(rest)
                    target = targets[0]

                    target_data = self.config.get_user_data(group_id, target)
                    if is_add:
                        target_data["points"] = target_data.get("points", 0) + amount
                        self.config.set_user_data(group_id, target, target_data)
                        return f"已给对方增加 {amount} 积分"
                    else:
                        target_data["points"] = max(0, target_data.get("points", 0) - amount)
                        self.config.set_user_data(group_id, target, target_data)
                        return f"已扣除对方 {amount} 积分"

        # 银行配置（管理员）
        if self.permission.is_group_admin(group_id, user_id, event):
            if text.startswith("银行利润 "):
                rest = text[5:].strip()
                if rest.isdigit():
                    value = int(rest)
                    if 0 <= value <= 100:
                        self.config.set_value(group_id, "银行利润", value)
                        return f"已设置银行利润为 {value}%"

            if text.startswith("银行利息 "):
                rest = text[5:].strip()
                if rest.isdigit():
                    value = int(rest)
                    if 0 <= value <= 100:
                        self.config.set_value(group_id, "银行利息", value)
                        return f"已设置银行利息为 {value}%"

        return None
