"""
撤回系统处理器
"""
from typing import TYPE_CHECKING, Optional, List
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from core.api import API


class RecallHandler:
    """撤回系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def parse_at(self, text: str) -> List[int]:
        """解析 @ 的用户"""
        pattern = r"\[CQ:at,qq=(\d+)[^\]]*\]"
        matches = re.findall(pattern, text)
        return [int(qq) for qq in matches]

    async def handle(self, group_id: int, user_id: int, text: str, api: "API", event=None) -> Optional[str]:
        """处理撤回系统命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 撤回 条数
        if text.startswith("撤回 ") and not self.parse_at(text):
            rest = text[3:].strip()
            if rest.isdigit():
                count = min(int(rest), 100)
                # 获取历史消息并撤回
                history = await api.get_group_msg_history(group_id, count=count)
                messages = history.get("messages", [])
                recalled = 0
                for msg in messages:
                    try:
                        await api.delete_msg(msg.get("message_id"))
                        recalled += 1
                    except Exception:
                        pass
                return f"已撤回 {recalled} 条消息"

        # 撤回@某人 [条数]
        if text.startswith("撤回"):
            targets = self.parse_at(text)
            if targets:
                rest = re.sub(r"\[CQ:at,qq=\d+[^\]]*\]", "", text[2:]).strip()
                count = 10  # 默认10条
                if rest.isdigit():
                    count = min(int(rest), 100)

                # 获取历史消息
                history = await api.get_group_msg_history(group_id, count=100)
                messages = history.get("messages", [])

                recalled = 0
                for msg in messages:
                    if msg.get("user_id") in targets and recalled < count:
                        try:
                            await api.delete_msg(msg.get("message_id"))
                            recalled += 1
                        except Exception:
                            pass

                return f"已撤回 {recalled} 条消息"

        # 指定撤回@某人
        if text.startswith("指定撤回"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    self.config.add_to_list(group_id, "指定撤回名单", target)
                return f"已将 {len(targets)} 人加入指定撤回名单"

        # 取消撤回@某人
        if text.startswith("取消撤回"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    self.config.remove_from_list(group_id, "指定撤回名单", target)
                return f"已将 {len(targets)} 人移出指定撤回名单"

        # 指定撤回名单
        if text == "指定撤回名单":
            recall_list = self.config.get_list(group_id, "指定撤回名单")
            if not recall_list:
                return "指定撤回名单为空"
            return "指定撤回名单:\n" + "\n".join([str(qq) for qq in recall_list])

        return None

    async def check_auto_recall(self, group_id: int, user_id: int, message_id: int, api: "API") -> bool:
        """检查是否需要自动撤回"""
        recall_list = self.config.get_list(group_id, "指定撤回名单")
        if user_id in recall_list:
            try:
                await api.delete_msg(message_id)
                return True
            except Exception:
                pass
        return False
