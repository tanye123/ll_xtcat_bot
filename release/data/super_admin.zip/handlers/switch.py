"""
开关系统处理器
"""
from typing import TYPE_CHECKING, Optional, Tuple

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker

# 所有开关名称
ALL_SWITCHES = [
    # 开关系统
    "菜单", "休闲", "匿名", "点歌", "图片菜单", "图片模式",
    # 签到配置
    "签到", "发言自动签到",
    # 提醒系统
    "退群提示", "被踢提示", "上管提示", "下管提示",
    # 入群配置
    "入群欢迎", "入群奖励", "入群私聊", "入群扩列",
    # 邀请配置
    "邀请回复", "邀请奖励", "邀请扩列",
    # 扩展群管
    "防闪照", "防撤回", "复读机",
    "字数禁言", "字数撤回", "字数踢人",
    "字数禁言提示", "字数撤回提示", "字数踢人提示",
    # 银行系统
    "银行", "转账", "打劫",
    # 入群验证
    "入群验证", "发言验证", "加法验证", "静默验证", "入群验证码", "私聊验证码",
    # 入群审核
    "入群审核", "进群自动同意", "进群群内询问",
    "入群检测等级", "入群检测昵称", "入群检测签名", "黑名单禁止入群",
    # 榜单系统
    "榜单",
    # 广告杀手
    "撤回图片", "撤回表情", "撤回号码", "撤回链接", "撤回签到",
    "撤回回执", "撤回卡片", "撤回群链", "撤回匿名", "撤回语音",
    "撤回视频", "撤回转发", "撤回闪照", "撤回涂鸦",
    # 刷屏检测
    "刷屏检测", "刷屏禁言", "刷屏撤回", "刷屏踢出",
    "刷屏禁言提示", "刷屏撤回提示", "刷屏踢出提示",
    # 黑白名单
    "退群拉黑", "踢出拉黑",
    # 问答系统
    "问答",
    # 禁词系统
    "关键词禁言", "关键词撤回", "关键词踢人",
    "关键词禁言提示", "关键词撤回提示", "关键词踢人提示",
    # 拉黑配置
    "发言提示", "发言禁言", "发言踢出",
    "发言禁言提示", "发言踢出提示",
    # 超管命令
    "管理员模式",
]


class SwitchHandler:
    """开关系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def parse_switch_command(self, text: str) -> Optional[Tuple[str, bool]]:
        """解析开关命令"""
        text = text.strip()

        for name in ALL_SWITCHES:
            if text == f"{name}开":
                return (name, True)
            elif text == f"{name}关":
                return (name, False)

        return None

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理开关命令"""
        result = self.parse_switch_command(text)
        if not result:
            return None

        name, value = result

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return "权限不足，需要群管权限"

        # 设置开关
        self.config.set_switch(group_id, name, value)

        status = "开启" if value else "关闭"
        return f"已{status}【{name}】功能"
