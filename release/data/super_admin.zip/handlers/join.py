"""
入群/邀请配置处理器
"""
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class JoinHandler:
    """入群/邀请配置处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理入群/邀请配置命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 入群欢迎 内容
        if text.startswith("入群欢迎 "):
            content = text[5:].strip()
            if content:
                self.config.set_text(group_id, "入群欢迎", content)
                return "已设置入群欢迎内容"

        # 入群私聊 内容
        if text.startswith("入群私聊 "):
            content = text[5:].strip()
            if content:
                self.config.set_text(group_id, "入群私聊", content)
                return "已设置入群私聊内容"

        # 入群奖励 积分
        if text.startswith("入群奖励 "):
            rest = text[5:].strip()
            if rest.isdigit():
                value = int(rest)
                self.config.set_value(group_id, "入群奖励积分", value)
                return f"已设置入群奖励为 {value} 积分"

        # 邀请回复 内容
        if text.startswith("邀请回复 "):
            content = text[5:].strip()
            if content:
                self.config.set_text(group_id, "邀请回复", content)
                return "已设置邀请回复内容"

        # 邀请奖励 积分
        if text.startswith("邀请奖励 "):
            rest = text[5:].strip()
            if rest.isdigit():
                value = int(rest)
                self.config.set_value(group_id, "邀请奖励积分", value)
                return f"已设置邀请奖励为 {value} 积分"

        return None

    def get_welcome_message(self, group_id: int, variables: dict) -> Optional[str]:
        """获取入群欢迎消息"""
        if not self.config.get_switch(group_id, "入群欢迎"):
            return None

        template = self.config.get_text(group_id, "入群欢迎")
        if not template:
            return None

        for key, value in variables.items():
            template = template.replace(f"{{{key}}}", str(value))

        return template

    def get_private_message(self, group_id: int, variables: dict) -> Optional[str]:
        """获取入群私聊消息"""
        if not self.config.get_switch(group_id, "入群私聊"):
            return None

        template = self.config.get_text(group_id, "入群私聊")
        if not template:
            return None

        for key, value in variables.items():
            template = template.replace(f"{{{key}}}", str(value))

        return template

    def get_invite_message(self, group_id: int, variables: dict) -> Optional[str]:
        """获取邀请回复消息"""
        if not self.config.get_switch(group_id, "邀请回复"):
            return None

        template = self.config.get_text(group_id, "邀请回复")
        if not template:
            return None

        for key, value in variables.items():
            template = template.replace(f"{{{key}}}", str(value))

        return template

    def get_join_reward(self, group_id: int) -> int:
        """获取入群奖励积分"""
        if not self.config.get_switch(group_id, "入群奖励"):
            return 0
        return self.config.get_value(group_id, "入群奖励积分")

    def get_invite_reward(self, group_id: int) -> int:
        """获取邀请奖励积分"""
        if not self.config.get_switch(group_id, "邀请奖励"):
            return 0
        return self.config.get_value(group_id, "邀请奖励积分")
