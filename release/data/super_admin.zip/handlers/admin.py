"""
超管/主人命令处理器
"""
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Optional, List
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class AdminHandler:
    """超管/主人命令处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def parse_at(self, text: str) -> List[int]:
        """解析 @ 的用户"""
        pattern = r"\[CQ:at,qq=(\d+)[^\]]*\]"
        matches = re.findall(pattern, text)
        return [int(qq) for qq in matches]

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理超管/主人命令"""
        text = text.strip()

        # 查询授权
        if text == "查询授权":
            return self._query_authorization(group_id)

        # 超管命令
        if self.permission.is_super_admin(group_id, user_id):
            result = self._handle_super_admin(group_id, user_id, text, event)
            if result:
                return result

        # 主人命令
        if self.permission.is_owner(user_id):
            result = self._handle_owner(group_id, user_id, text, event)
            if result:
                return result

        return None

    def _query_authorization(self, group_id: int) -> str:
        """查询授权"""
        expire = self.config.get_expire_date(group_id)
        super_admin_list = self.config.get_super_admin_list(group_id)
        owner_list = self.permission.get_owner_list()

        if not expire:
            expire_str = "永久授权"
        else:
            expire_str = expire

        super_admin_str = ", ".join([str(qq) for qq in super_admin_list]) if super_admin_list else "未设置"
        owner_str = ", ".join([str(qq) for qq in owner_list]) if owner_list else "未设置"

        return f"""授权信息
╭───────────╮
┣群号: {group_id}
┣到期时间: {expire_str}
┣主人: {owner_str}
┣超管: {super_admin_str}
╰───────────╯"""

    def _handle_super_admin(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理超管命令"""
        # 加群管 QQ号
        if text.startswith("加群管 "):
            rest = text[4:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.add_to_list(group_id, "群管列表", qq)
                return f"已添加 {qq} 为群管"

        # 加群管@某人
        if text.startswith("加群管"):
            targets = self.parse_at(text)
            if targets:
                for qq in targets:
                    self.config.add_to_list(group_id, "群管列表", qq)
                return f"已添加 {len(targets)} 人为群管"

        # 删群管 QQ号
        if text.startswith("删群管 "):
            rest = text[4:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.remove_from_list(group_id, "群管列表", qq)
                return f"已删除群管 {qq}"

        # 删群管@某人
        if text.startswith("删群管"):
            targets = self.parse_at(text)
            if targets:
                for qq in targets:
                    self.config.remove_from_list(group_id, "群管列表", qq)
                return f"已删除 {len(targets)} 个群管"

        # 查看群管列表
        if text == "查看群管列表":
            admin_list = self.config.get_list(group_id, "群管列表")
            if not admin_list:
                return "群管列表为空"
            return "群管列表:\n" + "\n".join([str(qq) for qq in admin_list])

        # 清空群管列表
        if text == "清空群管列表":
            self.config.clear_list(group_id, "群管列表")
            return "已清空群管列表"

        # 刷新管理员列表
        if text == "刷新管理员列表":
            return "管理员列表已刷新"

        return None

    def _handle_owner(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理主人命令"""
        # 运行状态
        if text == "运行状态":
            owner_list = self.permission.get_owner_list()
            return f"""运行状态
╭───────────╮
┣状态: 正常运行
┣时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
┣主人数量: {len(owner_list)}
╰───────────╯"""

        # 设置主人 QQ号
        if text.startswith("设置主人 "):
            rest = text[5:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.add_owner(qq)
                return f"已添加 {qq} 为主人"

        # 设置主人@某人
        if text.startswith("设置主人"):
            targets = self.parse_at(text)
            if targets:
                for qq in targets:
                    self.config.add_owner(qq)
                return f"已添加 {len(targets)} 人为主人"

        # 删除主人 QQ号
        if text.startswith("删除主人 "):
            rest = text[5:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.remove_owner(qq)
                return f"已删除主人 {qq}"

        # 查看主人
        if text == "查看主人":
            owner_list = self.permission.get_owner_list()
            if not owner_list:
                return "主人列表为空"
            return "主人列表:\n" + "\n".join([str(qq) for qq in owner_list])

        # 加授权 天数
        if text.startswith("加授权 "):
            rest = text[4:].strip()
            if rest.isdigit():
                days = int(rest)
                current = self.config.get_expire_date(group_id)
                if current:
                    try:
                        current_date = datetime.strptime(current, "%Y-%m-%d")
                    except ValueError:
                        current_date = datetime.now()
                else:
                    current_date = datetime.now()

                new_date = current_date + timedelta(days=days)
                self.config.set_expire_date(group_id, new_date.strftime("%Y-%m-%d"))
                return f"已增加 {days} 天授权，到期时间: {new_date.strftime('%Y-%m-%d')}"

        # 减授权 天数
        if text.startswith("减授权 "):
            rest = text[4:].strip()
            if rest.isdigit():
                days = int(rest)
                current = self.config.get_expire_date(group_id)
                if current:
                    try:
                        current_date = datetime.strptime(current, "%Y-%m-%d")
                        new_date = current_date - timedelta(days=days)
                        self.config.set_expire_date(group_id, new_date.strftime("%Y-%m-%d"))
                        return f"已减少 {days} 天授权，到期时间: {new_date.strftime('%Y-%m-%d')}"
                    except ValueError:
                        pass
                return "当前无授权时间限制"

        # 删除本群授权
        if text == "删除本群授权":
            self.config.set_expire_date(group_id, datetime.now().strftime("%Y-%m-%d"))
            return "已删除本群授权"

        # 设置超管 QQ号
        if text.startswith("设置超管 "):
            rest = text[5:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.add_super_admin(group_id, qq)
                return f"已添加 {qq} 为超管"

        # 设置超管@某人
        if text.startswith("设置超管"):
            targets = self.parse_at(text)
            if targets:
                for qq in targets:
                    self.config.add_super_admin(group_id, qq)
                return f"已添加 {len(targets)} 人为超管"

        # 删除超管 QQ号
        if text.startswith("删除超管 "):
            rest = text[5:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.remove_super_admin(group_id, qq)
                return f"已删除超管 {qq}"

        # 删除超管@某人
        if text.startswith("删除超管"):
            targets = self.parse_at(text)
            if targets:
                for qq in targets:
                    self.config.remove_super_admin(group_id, qq)
                return f"已删除 {len(targets)} 个超管"

        # 查看超管
        if text == "查看超管":
            super_admin_list = self.config.get_super_admin_list(group_id)
            if not super_admin_list:
                return "超管列表为空"
            return "超管列表:\n" + "\n".join([str(qq) for qq in super_admin_list])

        # 全局拉黑@某人
        if text.startswith("全局拉黑"):
            targets = self.parse_at(text)
            if targets:
                for qq in targets:
                    self.config.add_global_blacklist(qq)
                return f"已全局拉黑 {len(targets)} 人"
            # 全局拉黑 QQ号
            rest = text[4:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.add_global_blacklist(qq)
                return f"已全局拉黑 {qq}"

        # 删全局黑@某人
        if text.startswith("删全局黑"):
            targets = self.parse_at(text)
            if targets:
                for qq in targets:
                    self.config.remove_global_blacklist(qq)
                return f"已删除 {len(targets)} 人的全局黑名单"
            # 删全局黑 QQ号
            rest = text[4:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.remove_global_blacklist(qq)
                return f"已删除 {qq} 的全局黑名单"

        # 查看全局黑名单
        if text == "查看全局黑名单":
            blacklist = self.config.get_global_blacklist()
            if not blacklist:
                return "全局黑名单为空"
            return "全局黑名单:\n" + "\n".join([str(qq) for qq in blacklist])

        return None
