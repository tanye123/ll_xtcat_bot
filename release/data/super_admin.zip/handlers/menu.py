"""
菜单系统处理器
"""
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from ..utils.formatter import MessageFormatter


class MenuHandler:
    """菜单处理器"""

    # 子菜单定义
    SUBMENUS = {
        "开关系统": {
            "permission": "admin",
            "items": [
                {"text": "菜单开 / 关", "switch": "菜单"},
                {"text": "休闲开 / 关", "switch": "休闲"},
                {"text": "匿名开 / 关", "switch": "匿名"},
                {"text": "点歌开 / 关", "switch": "点歌"},
                {"text": "图片菜单开 / 关", "switch": "图片菜单"},
                {"text": "图片模式开 / 关", "switch": "图片模式"},
            ]
        },
        "休闲系统": {
            "permission": "all",
            "items": [
                {"text": "看美女"},
                {"text": "看帅哥"},
                {"text": "彩虹屁"},
                {"text": "毒鸡汤"},
                {"text": "绕口令"},
                {"text": "舔狗日记"},
                {"text": "土味情话"},
                {"text": "网易云热评"},
            ]
        },
        "签到配置": {
            "permission": "admin",
            "items": [
                {"text": "签到开/关", "switch": "签到"},
                {"text": "签到奖励10～999"},
                {"text": "连签奖励10～999"},
                {"text": "签到奖励10", "value": "签到奖励"},
                {"text": "连签奖励10", "value": "连签奖励"},
                {"text": "发言自动签到开/关", "switch": "发言自动签到"},
            ]
        },
        "统计系统": {
            "permission": "admin",
            "items": [
                {"text": "邀请统计"},
                {"text": "发言统计"},
                {"text": "查邀请@某人"},
                {"text": "查邀请 QQ号"},
                {"text": "查发言@某人"},
                {"text": "查发言 QQ号"},
            ]
        },
        "超管命令": {
            "permission": "super",
            "items": [
                {"text": "查询授权"},
                {"text": "加群管 QQ号"},
                {"text": "删群管 QQ号"},
                {"text": "加/删群管@某人"},
                {"text": "刷新管理员列表"},
                {"text": "查看/清空群管列表"},
                {"text": "图片菜单开/关", "switch": "图片菜单"},
                {"text": "图片模式开/关", "switch": "图片模式"},
                {"text": "管理员模式开/关", "switch": "管理员模式"},
            ]
        },
        "主人命令": {
            "permission": "owner",
            "items": [
                {"text": "查询授权"},
                {"text": "运行状态"},
                {"text": "加授权 天数"},
                {"text": "减授权 天数"},
                {"text": "删除本群授权"},
                {"text": "全局拉黑@某人"},
                {"text": "删全局黑@某人"},
                {"text": "设置超管 QQ号"},
            ]
        },
        "提醒系统": {
            "permission": "admin",
            "items": [
                {"text": "退群提示 内容"},
                {"text": "被踢提示 内容"},
                {"text": "上管提示 内容"},
                {"text": "下管提示 内容"},
                {"text": "查看提示系统变量"},
                {"text": "退群提示开/关", "switch": "退群提示"},
                {"text": "被踢提示开/关", "switch": "被踢提示"},
                {"text": "上管提示开/关", "switch": "上管提示"},
                {"text": "下管提示开/关", "switch": "下管提示"},
            ]
        },
        "基础群管": {
            "permission": "admin",
            "items": [
                {"text": "开机/关机"},
                {"text": "全体禁言/解禁"},
                {"text": "禁言@某人 分钟"},
                {"text": "解禁@某人"},
                {"text": "踢@某人"},
                {"text": "踢黑@某人"},
                {"text": "清屏 行数"},
                {"text": "逐个艾特全员"},
                {"text": "艾特全体成员 内容"},
            ]
        },
        "入群配置": {
            "permission": "admin",
            "items": [
                {"text": "入群欢迎 内容"},
                {"text": "入群私聊 内容"},
                {"text": "入群奖励 积分", "value": "入群奖励积分"},
                {"text": "入群欢迎开/关", "switch": "入群欢迎"},
                {"text": "入群奖励开/关", "switch": "入群奖励"},
                {"text": "入群私聊开/关", "switch": "入群私聊"},
                {"text": "入群扩列开/关", "switch": "入群扩列"},
            ]
        },
        "邀请配置": {
            "permission": "admin",
            "items": [
                {"text": "邀请回复 内容"},
                {"text": "邀请奖励 积分", "value": "邀请奖励积分"},
                {"text": "邀请回复开/关", "switch": "邀请回复"},
                {"text": "邀请奖励开/关", "switch": "邀请奖励"},
                {"text": "邀请扩列开/关", "switch": "邀请扩列"},
            ]
        },
        "扩展群管": {
            "permission": "admin",
            "items": [
                {"text": "防闪照开/关", "switch": "防闪照"},
                {"text": "防撤回开/关", "switch": "防撤回"},
                {"text": "复读机开/关", "switch": "复读机"},
                {"text": "字数禁言开/关", "switch": "字数禁言"},
                {"text": "字数撤回开/关", "switch": "字数撤回"},
                {"text": "字数踢人开/关", "switch": "字数踢人"},
                {"text": "禁言字数 长度", "value": "禁言字数"},
                {"text": "撤回字数 长度", "value": "撤回字数"},
                {"text": "踢人字数 长度", "value": "踢人字数"},
                {"text": "字数禁言时间 分钟", "value": "字数禁言时间"},
                {"text": "字数禁言提示开/关", "switch": "字数禁言提示"},
                {"text": "字数撤回提示开/关", "switch": "字数撤回提示"},
                {"text": "字数踢人提示开/关", "switch": "字数踢人提示"},
            ]
        },
        "撤回系统": {
            "permission": "admin",
            "items": [
                {"text": "撤回 条数"},
                {"text": "撤回@某人"},
                {"text": "撤回@某人 条数"},
                {"text": "指定撤回@某人"},
                {"text": "取消撤回@某人"},
                {"text": "指定撤回名单"},
            ]
        },
        "银行系统": {
            "permission": "all",
            "items": [
                {"text": "我的积分"},
                {"text": "打劫@某人"},
                {"text": "劫狱@某人"},
                {"text": "存/取款 积分"},
                {"text": "贷/还款 积分"},
                {"text": "转账@某人 积分"},
                {"text": "加/减积分@某人 积分"},
                {"text": "银行开/关", "switch": "银行"},
                {"text": "转账开/关", "switch": "转账"},
                {"text": "打劫开/关", "switch": "打劫"},
                {"text": "银行利润 百分比", "value": "银行利润"},
                {"text": "银行利息 百分比", "value": "银行利息"},
            ]
        },
        "入群验证": {
            "permission": "admin",
            "items": [
                {"text": "验证时间 分钟", "value": "验证时间"},
                {"text": "入群验证开/关", "switch": "入群验证"},
                {"text": "发言验证开/关", "switch": "发言验证"},
                {"text": "加法验证开/关", "switch": "加法验证"},
                {"text": "静默验证开/关", "switch": "静默验证"},
                {"text": "入群验证码开/关", "switch": "入群验证码"},
                {"text": "私聊验证码开/关", "switch": "私聊验证码"},
            ]
        },
        "入群审核": {
            "permission": "admin",
            "items": [
                {"text": "入群等级 级别", "value": "入群等级"},
                {"text": "入群审核开/关", "switch": "入群审核"},
                {"text": "加/删禁入昵称 内容"},
                {"text": "加/删禁入签名 内容"},
                {"text": "进群自动同意开/关", "switch": "进群自动同意"},
                {"text": "进群群内询问开/关", "switch": "进群群内询问"},
                {"text": "入群检测等级开/关", "switch": "入群检测等级"},
                {"text": "入群检测昵称开/关", "switch": "入群检测昵称"},
                {"text": "入群检测签名开/关", "switch": "入群检测签名"},
                {"text": "查看/清空禁入昵称列表"},
                {"text": "查看/清空禁入签名列表"},
                {"text": "黑名单禁止入群开/关", "switch": "黑名单禁止入群"},
            ]
        },
        "榜单系统": {
            "permission": "all",
            "items": [
                {"text": "榜单开/关", "switch": "榜单"},
                {"text": "财富排行"},
                {"text": "累签排行"},
                {"text": "连签排行"},
                {"text": "今日发言排行"},
                {"text": "本周发言排行"},
                {"text": "本月发言排行"},
                {"text": "有效邀请排行"},
            ]
        },
        "广告杀手": {
            "permission": "admin",
            "items": [
                {"text": "撤回图片开/关", "switch": "撤回图片"},
                {"text": "撤回表情开/关", "switch": "撤回表情"},
                {"text": "撤回号码开/关", "switch": "撤回号码"},
                {"text": "撤回链接开/关", "switch": "撤回链接"},
                {"text": "撤回签到开/关", "switch": "撤回签到"},
                {"text": "撤回回执开/关", "switch": "撤回回执"},
                {"text": "撤回卡片开/关", "switch": "撤回卡片"},
                {"text": "撤回群链开/关", "switch": "撤回群链"},
                {"text": "撤回匿名开/关", "switch": "撤回匿名"},
                {"text": "撤回语音开/关", "switch": "撤回语音"},
                {"text": "撤回视频开/关", "switch": "撤回视频"},
                {"text": "撤回转发开/关", "switch": "撤回转发"},
                {"text": "撤回闪照开/关", "switch": "撤回闪照"},
                {"text": "撤回涂鸦开/关", "switch": "撤回涂鸦"},
            ]
        },
        "刷屏检测": {
            "permission": "admin",
            "items": [
                {"text": "设置刷屏检测规则"},
                {"text": "查看/清空刷屏检测规则"},
                {"text": "刷屏检测开/关", "switch": "刷屏检测"},
                {"text": "刷屏禁言开/关", "switch": "刷屏禁言"},
                {"text": "刷屏撤回开/关", "switch": "刷屏撤回"},
                {"text": "刷屏踢出开/关", "switch": "刷屏踢出"},
                {"text": "刷屏禁言时间 分钟", "value": "刷屏禁言时间"},
                {"text": "刷屏踢出机会 次数", "value": "刷屏踢出机会"},
                {"text": "刷屏禁言提示开/关", "switch": "刷屏禁言提示"},
                {"text": "刷屏撤回提示开/关", "switch": "刷屏撤回提示"},
                {"text": "刷屏踢出提示开/关", "switch": "刷屏踢出提示"},
            ]
        },
        "黑白名单": {
            "permission": "admin",
            "items": [
                {"text": "退群拉黑开/关", "switch": "退群拉黑"},
                {"text": "踢出拉黑开/关", "switch": "踢出拉黑"},
                {"text": "加黑名单+QQ/@某人"},
                {"text": "删黑名单+QQ/@某人"},
                {"text": "加白名单+QQ/@某人"},
                {"text": "删白名单+QQ/@某人"},
                {"text": "查看/清空黑名单列表"},
                {"text": "查看/清空白名单列表"},
                {"text": "加黑名单+QQ/@某人 原因"},
            ]
        },
        "问答系统": {
            "permission": "admin",
            "items": [
                {"text": "问答开/关", "switch": "问答"},
                {"text": "精准问1答2"},
                {"text": "模糊问1答2"},
                {"text": "精准问1私2"},
                {"text": "模糊问1私2"},
                {"text": "删精准/模糊 1"},
                {"text": "查看/清空精准问词库"},
                {"text": "查看/清空模糊问词库"},
            ]
        },
        "禁词系统": {
            "permission": "admin",
            "items": [
                {"text": "禁词禁言时间 分钟", "value": "禁词禁言时间"},
                {"text": "禁词踢人机会 次数", "value": "禁词踢人机会"},
                {"text": "加/删禁言关键词 内容"},
                {"text": "加/删撤回关键词 内容"},
                {"text": "加/删踢人关键词 内容"},
                {"text": "关键词禁言开/关", "switch": "关键词禁言"},
                {"text": "关键词撤回开/关", "switch": "关键词撤回"},
                {"text": "关键词踢人开/关", "switch": "关键词踢人"},
                {"text": "查看/清空禁言词列表"},
                {"text": "查看/清空撤回词列表"},
                {"text": "查看/清空踢人词列表"},
                {"text": "关键词禁言提示开/关", "switch": "关键词禁言提示"},
                {"text": "关键词撤回提示开/关", "switch": "关键词撤回提示"},
                {"text": "关键词踢人提示开/关", "switch": "关键词踢人提示"},
            ]
        },
        "拉黑配置": {
            "permission": "super",
            "items": [
                {"text": "查看拉黑变量"},
                {"text": "发言提示开/关", "switch": "发言提示"},
                {"text": "发言禁言开/关", "switch": "发言禁言"},
                {"text": "发言踢出开/关", "switch": "发言踢出"},
                {"text": "发言提示内容 内容"},
                {"text": "禁言提示内容 内容"},
                {"text": "踢出提示内容 内容"},
                {"text": "发言提示间隔 秒", "value": "发言提示间隔"},
                {"text": "发言禁言时间 分钟", "value": "发言禁言时间"},
                {"text": "发言禁言提示开/关", "switch": "发言禁言提示"},
                {"text": "发言踢出提示开/关", "switch": "发言踢出提示"},
            ]
        },
    }

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def get_main_menu(self) -> str:
        """获取主菜单"""
        return """欢迎使用超级群管
◇━━整体功能━━◇
基础群管 扩展群管
入群审核 入群验证
广告杀手 撤回系统
黑白名单 拉黑配置
提醒系统 刷屏检测
入群配置 邀请配置
问答系统 榜单系统
禁词系统 银行系统
签到配置 休闲系统
统计系统 超管命令
主人命令 开关系统
◇━━━━━━━━━━◇
PS: 发相应文字查看
如：基础群管"""

    def get_submenu(self, group_id: int, menu_name: str, user_id: int, event=None) -> str:
        """获取子菜单"""
        if menu_name not in self.SUBMENUS:
            return None

        menu_def = self.SUBMENUS[menu_name]
        perm_level = menu_def["permission"]

        # 获取权限名称
        perm_names = {
            "all": "所有人",
            "admin": "群管",
            "super": "超管",
            "owner": "主人",
        }
        perm_name = perm_names.get(perm_level, "群管")

        # 构建菜单项
        lines = [
            f"欢迎使用超级群管",
            f"{perm_name}可用",
            "╭───────────╮",
        ]

        for item in menu_def["items"]:
            text = item["text"]
            status_str = ""

            # 获取开关状态
            if "switch" in item:
                switch_name = item["switch"]
                status = self.config.get_switch(group_id, switch_name)
                status_str = "【【开】】" if status else "【【关】】"

            # 获取数值状态
            elif "value" in item:
                value_name = item["value"]
                value = self.config.get_value(group_id, value_name)
                status_str = f"【【{value}】】"

            lines.append(f"┣{text}{status_str}")

        lines.extend([
            "╰───────────╯",
            "到此结束",
        ])

        return "\n".join(lines)

    def is_menu_command(self, text: str) -> bool:
        """检查是否为菜单命令"""
        text = text.strip()
        return text in ("菜单", "help", "帮助") or text in self.SUBMENUS

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> str:
        """处理菜单命令"""
        text = text.strip()

        # 主菜单
        if text in ("菜单", "help", "帮助"):
            if not self.config.get_switch(group_id, "菜单"):
                return None
            return self.get_main_menu()

        # 子菜单
        if text in self.SUBMENUS:
            if not self.config.get_switch(group_id, "菜单"):
                return None
            return self.get_submenu(group_id, text, user_id, event)

        return None
