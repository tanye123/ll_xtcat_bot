"""
榜单系统处理器
"""
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Optional, List

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class RankHandler:
    """榜单系统处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理榜单命令"""
        text = text.strip()

        # 检查榜单功能是否开启
        if not self.config.get_switch(group_id, "榜单"):
            return None

        # 财富排行
        if text == "财富排行":
            return self._get_wealth_rank(group_id)

        # 累签排行
        if text == "累签排行":
            return self._get_total_sign_rank(group_id)

        # 连签排行
        if text == "连签排行":
            return self._get_continuous_sign_rank(group_id)

        # 今日发言排行
        if text == "今日发言排行":
            return self._get_message_rank(group_id, "today")

        # 本周发言排行
        if text == "本周发言排行":
            return self._get_message_rank(group_id, "week")

        # 本月发言排行
        if text == "本月发言排行":
            return self._get_message_rank(group_id, "month")

        # 有效邀请排行
        if text == "有效邀请排行":
            return self._get_invite_rank(group_id)

        return None

    def _get_wealth_rank(self, group_id: int) -> str:
        """获取财富排行"""
        users = self.config.get_all_users(group_id)
        if not users:
            return "暂无数据"

        # 计算总资产
        rank_data = []
        for uid, data in users.items():
            points = data.get("points", 0)
            bank = data.get("bank", 0)
            loan = data.get("loan", 0)
            total = points + bank - loan
            nickname = data.get("nickname", uid)
            rank_data.append({"nickname": nickname, "value": total})

        # 排序
        rank_data.sort(key=lambda x: x["value"], reverse=True)

        return self._format_rank("财富排行", rank_data[:10], "积分")

    def _get_total_sign_rank(self, group_id: int) -> str:
        """获取累签排行"""
        users = self.config.get_all_users(group_id)
        if not users:
            return "暂无数据"

        rank_data = []
        for uid, data in users.items():
            sign = data.get("sign", {})
            total_days = sign.get("total_days", 0)
            nickname = data.get("nickname", uid)
            if total_days > 0:
                rank_data.append({"nickname": nickname, "value": total_days})

        rank_data.sort(key=lambda x: x["value"], reverse=True)

        return self._format_rank("累签排行", rank_data[:10], "天")

    def _get_continuous_sign_rank(self, group_id: int) -> str:
        """获取连签排行"""
        users = self.config.get_all_users(group_id)
        if not users:
            return "暂无数据"

        rank_data = []
        for uid, data in users.items():
            sign = data.get("sign", {})
            continuous_days = sign.get("continuous_days", 0)
            nickname = data.get("nickname", uid)
            if continuous_days > 0:
                rank_data.append({"nickname": nickname, "value": continuous_days})

        rank_data.sort(key=lambda x: x["value"], reverse=True)

        return self._format_rank("连签排行", rank_data[:10], "天")

    def _get_message_rank(self, group_id: int, period: str) -> str:
        """获取发言排行"""
        stats = self.config.get_stats(group_id)
        messages = stats.get("messages", {})

        if not messages:
            return "暂无数据"

        today = datetime.now()

        # 确定日期范围
        if period == "today":
            dates = [today.strftime("%Y-%m-%d")]
            title = "今日发言排行"
        elif period == "week":
            dates = [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]
            title = "本周发言排行"
        else:  # month
            dates = [(today - timedelta(days=i)).strftime("%Y-%m-%d") for i in range(30)]
            title = "本月发言排行"

        # 统计
        rank_data = []
        for uid, date_counts in messages.items():
            total = sum(date_counts.get(d, 0) for d in dates)
            if total > 0:
                user_data = self.config.get_user_data(group_id, int(uid))
                nickname = user_data.get("nickname", uid)
                rank_data.append({"nickname": nickname, "value": total})

        rank_data.sort(key=lambda x: x["value"], reverse=True)

        return self._format_rank(title, rank_data[:10], "条")

    def _get_invite_rank(self, group_id: int) -> str:
        """获取邀请排行"""
        stats = self.config.get_stats(group_id)
        invites = stats.get("invites", {})

        if not invites:
            return "暂无数据"

        rank_data = []
        for uid, invited_list in invites.items():
            count = len(invited_list)
            if count > 0:
                user_data = self.config.get_user_data(group_id, int(uid))
                nickname = user_data.get("nickname", uid)
                rank_data.append({"nickname": nickname, "value": count})

        rank_data.sort(key=lambda x: x["value"], reverse=True)

        return self._format_rank("有效邀请排行", rank_data[:10], "人")

    def _format_rank(self, title: str, data: List[dict], unit: str) -> str:
        """格式化排行榜"""
        if not data:
            return f"{title}\n暂无数据"

        lines = [title, "╭───────────╮"]
        for i, item in enumerate(data, 1):
            lines.append(f"┣{i}. {item['nickname']}: {item['value']}{unit}")
        lines.append("╰───────────╯")

        return "\n".join(lines)
