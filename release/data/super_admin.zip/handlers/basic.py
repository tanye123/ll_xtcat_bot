"""
基础群管处理器
"""
from typing import TYPE_CHECKING, Optional, List, Tuple
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from core.api import API


class BasicHandler:
    """基础群管处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def parse_at(self, text: str) -> List[int]:
        """解析 @ 的用户"""
        # 匹配 [CQ:at,qq=数字] 或 [CQ:at,qq=数字,name=xxx] 等格式
        pattern = r"\[CQ:at,qq=(\d+)[^\]]*\]"
        matches = re.findall(pattern, text)
        return [int(qq) for qq in matches]

    async def handle(self, group_id: int, user_id: int, text: str, api: "API", event=None) -> Optional[str]:
        """处理基础群管命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 开机/关机
        if text == "开机":
            config = self.config.get_group_config(group_id)
            config["enabled"] = True
            self.config.save_config()
            return "机器人已开机"

        if text == "关机":
            config = self.config.get_group_config(group_id)
            config["enabled"] = False
            self.config.save_config()
            return "机器人已关机"

        # 全体禁言
        if text == "全体禁言":
            await api.set_group_whole_ban(group_id, True)
            return "已开启全体禁言"

        # 全体解禁
        if text in ("全体解禁", "解禁全体"):
            await api.set_group_whole_ban(group_id, False)
            return "已关闭全体禁言"

        # 禁言@某人 分钟
        if text.startswith("禁言"):
            targets = self.parse_at(text)
            if targets:
                # 提取时间参数
                rest = re.sub(r"\[CQ:at,qq=\d+[^\]]*\]", "", text[2:]).strip()
                duration = 10  # 默认10分钟
                if rest.isdigit():
                    duration = int(rest)

                for target in targets:
                    # 检查是否有权限禁言该用户
                    if self.permission.is_in_whitelist(group_id, target):
                        continue
                    await api.set_group_ban(group_id, target, duration * 60)

                return f"已禁言 {len(targets)} 人 {duration} 分钟"

        # 解禁@某人
        if text.startswith("解禁"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    await api.set_group_ban(group_id, target, 0)
                return f"已解禁 {len(targets)} 人"

        # 踢@某人
        if text.startswith("踢") and not text.startswith("踢黑"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    if self.permission.is_in_whitelist(group_id, target):
                        continue
                    await api.set_group_kick(group_id, target, False)
                return f"已踢出 {len(targets)} 人"

        # 踢黑@某人
        if text.startswith("踢黑"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    if self.permission.is_in_whitelist(group_id, target):
                        continue
                    # 先加黑名单再踢
                    self.config.add_to_list(group_id, "黑名单", target)
                    await api.set_group_kick(group_id, target, True)
                return f"已踢出并拉黑 {len(targets)} 人"

        # 清屏 行数
        if text.startswith("清屏"):
            rest = text[2:].strip()
            count = 10  # 默认10条
            if rest.isdigit():
                count = min(int(rest), 50)  # 最多50条

            # 发送空白消息清屏
            clear_msg = "\n" * count
            await api.send_group_msg(group_id, clear_msg)
            return None  # 不回复

        # 艾特全体成员 内容
        if text.startswith("艾特全体成员 "):
            content = text[7:].strip()
            if content:
                msg = [
                    {"type": "at", "data": {"qq": "all"}},
                    {"type": "text", "data": {"text": f" {content}"}}
                ]
                await api.send_group_msg(group_id, msg)
                return None

        return None
