"""
命令处理器模块
"""
from .menu import MenuHandler
from .switch import SwitchHandler
from .leisure import LeisureHandler
from .sign import SignHandler
from .stats import StatsHandler
from .admin import AdminHandler
from .notify import NotifyHandler
from .basic import BasicHandler
from .join import JoinHandler
from .extend import ExtendHandler
from .recall import RecallHandler
from .bank import BankHandler
from .verify import VerifyHandler
from .rank import RankHandler
from .antiad import AntiAdHandler
from .antiflood import AntiFloodHandler
from .blacklist import BlacklistHandler
from .qa import QAHandler
from .keyword import KeywordHandler

__all__ = [
    "MenuHandler",
    "SwitchHandler",
    "LeisureHandler",
    "SignHandler",
    "StatsHandler",
    "AdminHandler",
    "NotifyHandler",
    "BasicHandler",
    "JoinHandler",
    "ExtendHandler",
    "RecallHandler",
    "BankHandler",
    "VerifyHandler",
    "RankHandler",
    "AntiAdHandler",
    "AntiFloodHandler",
    "BlacklistHandler",
    "QAHandler",
    "KeywordHandler",
]
