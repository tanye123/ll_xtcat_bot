"""
休闲系统处理器
"""
import aiohttp
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class LeisureHandler:
    """休闲系统处理器"""

    # API 配置
    APIS = {
        "看美女": "https://api.vvhan.com/api/girl",
        "看帅哥": "https://api.vvhan.com/api/boy",
        "彩虹屁": "https://api.vvhan.com/api/text/love",
        "毒鸡汤": "https://api.vvhan.com/api/text/poison",
        "绕口令": "https://api.vvhan.com/api/text/tongue",
        "舔狗日记": "https://api.vvhan.com/api/text/dog",
        "土味情话": "https://api.vvhan.com/api/text/qinghua",
        "网易云热评": "https://api.vvhan.com/api/text/hotcomments",
    }

    # 图片类型的命令
    IMAGE_COMMANDS = ["看美女", "看帅哥"]

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def is_leisure_command(self, text: str) -> bool:
        """检查是否为休闲命令"""
        return text.strip() in self.APIS

    async def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[dict]:
        """
        处理休闲命令

        Returns:
            {"type": "text", "content": "..."} 或
            {"type": "image", "url": "..."} 或
            None
        """
        text = text.strip()

        if text not in self.APIS:
            return None

        # 检查休闲功能是否开启
        if not self.config.get_switch(group_id, "休闲"):
            return None

        api_url = self.APIS[text]

        try:
            async with aiohttp.ClientSession() as session:
                if text in self.IMAGE_COMMANDS:
                    # 图片类型，直接返回 URL
                    return {"type": "image", "url": api_url}
                else:
                    # 文本类型，请求 API
                    async with session.get(api_url, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                        if resp.status == 200:
                            data = await resp.text()
                            # 尝试解析 JSON
                            try:
                                import json
                                json_data = json.loads(data)
                                if isinstance(json_data, dict):
                                    # 尝试获取常见的文本字段
                                    content = json_data.get("data") or json_data.get("text") or json_data.get("content") or str(json_data)
                                else:
                                    content = str(json_data)
                            except json.JSONDecodeError:
                                content = data

                            return {"type": "text", "content": content}
                        else:
                            return {"type": "text", "content": "获取失败，请稍后再试"}
        except Exception as e:
            return {"type": "text", "content": f"请求失败: {str(e)}"}
