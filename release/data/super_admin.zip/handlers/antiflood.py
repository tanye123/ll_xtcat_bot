"""
刷屏检测处理器
"""
import time
from collections import defaultdict
from typing import TYPE_CHECKING, Optional, Dict, List

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from core.api import API


class AntiFloodHandler:
    """刷屏检测处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission
        # 消息记录 {group_id: {user_id: [timestamp, ...]}}
        self._message_history: Dict[int, Dict[int, List[float]]] = defaultdict(lambda: defaultdict(list))
        # 违规次数 {group_id: {user_id: count}}
        self._violation_count: Dict[int, Dict[int, int]] = defaultdict(lambda: defaultdict(int))

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理刷屏检测配置命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 数值设置
        if text.startswith("刷屏禁言时间 "):
            rest = text[7:].strip()
            if rest.isdigit():
                value = int(rest)
                if 1 <= value <= 999:
                    self.config.set_value(group_id, "刷屏禁言时间", value)
                    return f"已设置刷屏禁言时间为 {value} 分钟"

        if text.startswith("刷屏踢出机会 "):
            rest = text[7:].strip()
            if rest.isdigit():
                value = int(rest)
                if 1 <= value <= 99:
                    self.config.set_value(group_id, "刷屏踢出机会", value)
                    return f"已设置刷屏踢出机会为 {value} 次"

        # 设置刷屏检测规则
        if text == "设置刷屏检测规则":
            return """刷屏检测规则说明
默认规则: 10秒内发送5条消息视为刷屏
可通过修改配置文件自定义规则"""

        # 查看刷屏检测规则
        if text == "查看刷屏检测规则":
            return """当前刷屏检测规则
╭───────────╮
┣时间窗口: 10秒
┣消息阈值: 5条
╰───────────╯"""

        return None

    async def check_flood(self, group_id: int, user_id: int, message_id: int, api: "API") -> Optional[str]:
        """
        检查是否刷屏

        Returns:
            处理结果或 None
        """
        # 检查功能是否开启
        if not self.config.get_switch(group_id, "刷屏检测"):
            return None

        # 检查白名单
        if self.permission.is_in_whitelist(group_id, user_id):
            return None

        # 检查管理员
        if self.permission.is_group_admin(group_id, user_id):
            return None

        current_time = time.time()

        # 记录消息
        self._message_history[group_id][user_id].append(current_time)

        # 清理过期记录（保留最近60秒）
        self._message_history[group_id][user_id] = [
            t for t in self._message_history[group_id][user_id]
            if current_time - t < 60
        ]

        # 检查10秒内的消息数量
        recent_messages = [
            t for t in self._message_history[group_id][user_id]
            if current_time - t < 10
        ]

        if len(recent_messages) < 5:
            return None

        # 触发刷屏检测
        result = None

        # 撤回消息
        if self.config.get_switch(group_id, "刷屏撤回"):
            try:
                await api.delete_msg(message_id)
                if self.config.get_switch(group_id, "刷屏撤回提示"):
                    result = "检测到刷屏，消息已撤回"
            except Exception:
                pass

        # 禁言
        if self.config.get_switch(group_id, "刷屏禁言"):
            duration = self.config.get_value(group_id, "刷屏禁言时间")
            await api.set_group_ban(group_id, user_id, duration * 60)
            if self.config.get_switch(group_id, "刷屏禁言提示"):
                result = f"检测到刷屏，已禁言 {duration} 分钟"

        # 踢出
        if self.config.get_switch(group_id, "刷屏踢出"):
            self._violation_count[group_id][user_id] += 1
            max_chances = self.config.get_value(group_id, "刷屏踢出机会")

            if self._violation_count[group_id][user_id] >= max_chances:
                await api.set_group_kick(group_id, user_id, False)
                del self._violation_count[group_id][user_id]
                if self.config.get_switch(group_id, "刷屏踢出提示"):
                    result = "刷屏次数过多，已踢出群聊"
            else:
                remaining = max_chances - self._violation_count[group_id][user_id]
                if self.config.get_switch(group_id, "刷屏踢出提示"):
                    result = f"刷屏警告！还有 {remaining} 次机会"

        # 清空该用户的消息记录
        self._message_history[group_id][user_id] = []

        return result
