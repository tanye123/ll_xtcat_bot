"""
黑白名单处理器
"""
from typing import TYPE_CHECKING, Optional, List
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker


class BlacklistHandler:
    """黑白名单处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def parse_at(self, text: str) -> List[int]:
        """解析 @ 的用户"""
        pattern = r"\[CQ:at,qq=(\d+)[^\]]*\]"
        matches = re.findall(pattern, text)
        return [int(qq) for qq in matches]

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理黑白名单命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 加黑名单
        if text.startswith("加黑名单"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    self.config.add_to_list(group_id, "黑名单", target)
                return f"已将 {len(targets)} 人加入黑名单"

            # 加黑名单 QQ号 [原因]
            rest = text[4:].strip()
            if rest:
                parts = rest.split(" ", 1)
                if parts[0].isdigit():
                    qq = int(parts[0])
                    self.config.add_to_list(group_id, "黑名单", qq)
                    return f"已将 {qq} 加入黑名单"

        # 删黑名单
        if text.startswith("删黑名单"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    self.config.remove_from_list(group_id, "黑名单", target)
                return f"已将 {len(targets)} 人移出黑名单"

            rest = text[4:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.remove_from_list(group_id, "黑名单", qq)
                return f"已将 {qq} 移出黑名单"

        # 加白名单
        if text.startswith("加白名单"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    self.config.add_to_list(group_id, "白名单", target)
                return f"已将 {len(targets)} 人加入白名单"

            rest = text[4:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.add_to_list(group_id, "白名单", qq)
                return f"已将 {qq} 加入白名单"

        # 删白名单
        if text.startswith("删白名单"):
            targets = self.parse_at(text)
            if targets:
                for target in targets:
                    self.config.remove_from_list(group_id, "白名单", target)
                return f"已将 {len(targets)} 人移出白名单"

            rest = text[4:].strip()
            if rest.isdigit():
                qq = int(rest)
                self.config.remove_from_list(group_id, "白名单", qq)
                return f"已将 {qq} 移出白名单"

        # 查看黑名单列表
        if text == "查看黑名单列表":
            blacklist = self.config.get_list(group_id, "黑名单")
            if not blacklist:
                return "黑名单列表为空"
            return "黑名单列表:\n" + "\n".join([str(qq) for qq in blacklist])

        # 清空黑名单列表
        if text == "清空黑名单列表":
            self.config.clear_list(group_id, "黑名单")
            return "已清空黑名单列表"

        # 查看白名单列表
        if text == "查看白名单列表":
            whitelist = self.config.get_list(group_id, "白名单")
            if not whitelist:
                return "白名单列表为空"
            return "白名单列表:\n" + "\n".join([str(qq) for qq in whitelist])

        # 清空白名单列表
        if text == "清空白名单列表":
            self.config.clear_list(group_id, "白名单")
            return "已清空白名单列表"

        return None
