"""
入群验证/审核处理器
"""
import random
from typing import TYPE_CHECKING, Optional, Dict, List
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from core.api import API


class VerifyHandler:
    """入群验证/审核处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission
        # 待验证用户 {group_id: {user_id: {"answer": str, "time": float}}}
        self._pending_verify: Dict[int, Dict[int, Dict]] = {}

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理入群验证/审核配置命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 验证时间设置
        if text.startswith("验证时间 "):
            rest = text[5:].strip()
            if rest.isdigit():
                value = int(rest)
                if 1 <= value <= 60:
                    self.config.set_value(group_id, "验证时间", value)
                    return f"已设置验证时间为 {value} 分钟"
                else:
                    return "验证时间范围: 1~60 分钟"

        # 入群等级设置
        if text.startswith("入群等级 "):
            rest = text[5:].strip()
            if rest.isdigit():
                value = int(rest)
                if 1 <= value <= 100:
                    self.config.set_value(group_id, "入群等级", value)
                    return f"已设置入群等级为 {value} 级"
                else:
                    return "入群等级范围: 1~100"

        # 禁入昵称/签名列表操作
        list_configs = {
            "禁入昵称": "禁入昵称",
            "禁入签名": "禁入签名",
        }

        for cmd, list_name in list_configs.items():
            if text.startswith(f"加{cmd} "):
                content = text[len(f"加{cmd} "):].strip()
                if content:
                    self.config.add_to_list(group_id, list_name, content)
                    return f"已添加{cmd}: {content}"

            if text.startswith(f"删{cmd} "):
                content = text[len(f"删{cmd} "):].strip()
                if content:
                    self.config.remove_from_list(group_id, list_name, content)
                    return f"已删除{cmd}: {content}"

            if text == f"查看{cmd}列表":
                items = self.config.get_list(group_id, list_name)
                if not items:
                    return f"{cmd}列表为空"
                return f"{cmd}列表:\n" + "\n".join(items)

            if text == f"清空{cmd}列表":
                self.config.clear_list(group_id, list_name)
                return f"已清空{cmd}列表"

        return None

    def generate_verify_question(self, group_id: int) -> tuple:
        """生成验证问题"""
        if self.config.get_switch(group_id, "加法验证"):
            # 加法验证
            a = random.randint(1, 50)
            b = random.randint(1, 50)
            question = f"请回答: {a} + {b} = ?"
            answer = str(a + b)
        else:
            # 验证码
            answer = "".join([str(random.randint(0, 9)) for _ in range(4)])
            question = f"请回复验证码: {answer}"

        return question, answer

    def start_verify(self, group_id: int, user_id: int) -> Optional[str]:
        """开始验证"""
        if not self.config.get_switch(group_id, "入群验证"):
            return None

        import time
        question, answer = self.generate_verify_question(group_id)

        if group_id not in self._pending_verify:
            self._pending_verify[group_id] = {}

        self._pending_verify[group_id][user_id] = {
            "answer": answer,
            "time": time.time(),
        }

        timeout = self.config.get_value(group_id, "验证时间")
        return f"欢迎新成员！请在 {timeout} 分钟内完成验证\n{question}"

    def check_verify(self, group_id: int, user_id: int, text: str) -> Optional[str]:
        """检查验证答案"""
        if group_id not in self._pending_verify:
            return None
        if user_id not in self._pending_verify[group_id]:
            return None

        import time
        verify_data = self._pending_verify[group_id][user_id]
        timeout = self.config.get_value(group_id, "验证时间") * 60

        # 检查超时
        if time.time() - verify_data["time"] > timeout:
            del self._pending_verify[group_id][user_id]
            return "timeout"

        # 检查答案
        if text.strip() == verify_data["answer"]:
            del self._pending_verify[group_id][user_id]
            return "success"

        return None

    def is_pending_verify(self, group_id: int, user_id: int) -> bool:
        """检查是否在等待验证"""
        if group_id not in self._pending_verify:
            return False
        return user_id in self._pending_verify[group_id]

    async def check_join_request(self, group_id: int, user_id: int, comment: str, api: "API") -> tuple:
        """
        检查入群请求

        Returns:
            (approve: bool, reason: str)
        """
        # 检查黑名单
        if self.config.get_switch(group_id, "黑名单禁止入群"):
            if self.permission.is_in_blacklist(group_id, user_id):
                return False, "黑名单用户"

        # 检查等级
        if self.config.get_switch(group_id, "入群检测等级"):
            required_level = self.config.get_value(group_id, "入群等级")
            # 获取用户信息检查等级
            user_info = await api.get_stranger_info(user_id)
            user_level = user_info.get("level", 0)
            if user_level < required_level:
                return False, f"等级不足，需要 {required_level} 级"

        # 检查昵称
        if self.config.get_switch(group_id, "入群检测昵称"):
            user_info = await api.get_stranger_info(user_id)
            nickname = user_info.get("nickname", "")
            forbidden_names = self.config.get_list(group_id, "禁入昵称")
            for name in forbidden_names:
                if name in nickname:
                    return False, f"昵称包含禁止词: {name}"

        # 自动同意
        if self.config.get_switch(group_id, "进群自动同意"):
            return True, ""

        # 需要审核
        if self.config.get_switch(group_id, "入群审核"):
            return None, "等待审核"

        return True, ""
