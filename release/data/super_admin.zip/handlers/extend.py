"""
扩展群管处理器
"""
from typing import TYPE_CHECKING, Optional, List
import re

if TYPE_CHECKING:
    from ..config import ConfigManager
    from ..utils.permission import PermissionChecker
    from core.api import API


class ExtendHandler:
    """扩展群管处理器"""

    def __init__(self, config: "ConfigManager", permission: "PermissionChecker"):
        self.config = config
        self.permission = permission

    def handle(self, group_id: int, user_id: int, text: str, event=None) -> Optional[str]:
        """处理扩展群管配置命令"""
        text = text.strip()

        # 检查权限
        if not self.permission.is_group_admin(group_id, user_id, event):
            return None

        # 数值设置
        value_configs = {
            "禁言字数": ("禁言字数", 1, 9999),
            "撤回字数": ("撤回字数", 1, 9999),
            "踢人字数": ("踢人字数", 1, 9999),
            "字数禁言时间": ("字数禁言时间", 1, 999),
        }

        for cmd, (config_key, min_val, max_val) in value_configs.items():
            if text.startswith(f"{cmd} "):
                rest = text[len(cmd) + 1:].strip()
                if rest.isdigit():
                    value = int(rest)
                    if min_val <= value <= max_val:
                        self.config.set_value(group_id, config_key, value)
                        return f"已设置{cmd}为 {value}"
                    else:
                        return f"{cmd}范围: {min_val}~{max_val}"

        return None

    async def check_message_length(self, group_id: int, user_id: int, text: str, message_id: int, api: "API") -> Optional[str]:
        """检查消息长度"""
        # 检查白名单
        if self.permission.is_in_whitelist(group_id, user_id):
            return None

        # 检查管理员
        if self.permission.is_group_admin(group_id, user_id):
            return None

        msg_len = len(text)

        # 字数禁言
        if self.config.get_switch(group_id, "字数禁言"):
            limit = self.config.get_value(group_id, "禁言字数")
            if msg_len > limit:
                duration = self.config.get_value(group_id, "字数禁言时间")
                await api.set_group_ban(group_id, user_id, duration * 60)
                if self.config.get_switch(group_id, "字数禁言提示"):
                    return f"消息超过{limit}字，已禁言{duration}分钟"

        # 字数撤回
        if self.config.get_switch(group_id, "字数撤回"):
            limit = self.config.get_value(group_id, "撤回字数")
            if msg_len > limit:
                await api.delete_msg(message_id)
                if self.config.get_switch(group_id, "字数撤回提示"):
                    return f"消息超过{limit}字，已撤回"

        # 字数踢人
        if self.config.get_switch(group_id, "字数踢人"):
            limit = self.config.get_value(group_id, "踢人字数")
            if msg_len > limit:
                await api.set_group_kick(group_id, user_id, False)
                if self.config.get_switch(group_id, "字数踢人提示"):
                    return f"消息超过{limit}字，已踢出"

        return None
