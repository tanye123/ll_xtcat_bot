"""
超级群管配置管理
"""
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from datetime import datetime


# 功能权限定义
# all: 所有人可用, admin: 群管可用, super: 超管可用, owner: 主人可用
FEATURE_PERMISSIONS = {
    # 休闲功能 - 所有人可用
    "签到": "all",
    "我的积分": "all",
    "存款": "all",
    "取款": "all",
    "贷款": "all",
    "还款": "all",
    "转账": "all",
    "打劫": "all",
    "积分榜": "all",
    "签到榜": "all",
    "发言榜": "all",
    "邀请榜": "all",
    "菜单": "all",
    "help": "all",

    # 群管功能 - 群管可用
    "禁言": "admin",
    "解禁": "admin",
    "踢": "admin",
    "踢黑": "admin",
    "全体禁言": "admin",
    "全体解禁": "admin",
    "撤回": "admin",
    "清屏": "admin",
    "艾特全体成员": "admin",
    "开关配置": "admin",
    "入群配置": "admin",
    "邀请配置": "admin",
    "签到配置": "admin",
    "提醒配置": "admin",
    "扩展群管": "admin",
    "撤回系统": "admin",
    "入群验证": "admin",
    "入群审核": "admin",
    "广告杀手": "admin",
    "刷屏检测": "admin",
    "问答系统": "admin",
    "禁词系统": "admin",
    "黑白名单": "admin",
    "加黑名单": "admin",
    "删黑名单": "admin",
    "加白名单": "admin",
    "删白名单": "admin",
    "加积分": "admin",
    "减积分": "admin",

    # 超管功能 - 超管可用
    "加群管": "super",
    "删群管": "super",
    "查看群管列表": "super",
    "清空群管列表": "super",
    "刷新管理员列表": "super",

    # 主人功能 - 主人可用
    "运行状态": "owner",
    "加授权": "owner",
    "减授权": "owner",
    "删除本群授权": "owner",
    "设置超管": "owner",
    "删除超管": "owner",
    "全局拉黑": "owner",
    "删全局黑": "owner",
    "设置主人": "owner",
    "查看主人": "owner",
}

# 默认全局配置
DEFAULT_GLOBAL_CONFIG = {
    "owner_list": [],  # 主人QQ列表
    "global_blacklist": [],  # 全局黑名单
    "global_whitelist": [],  # 全局白名单
}

# 默认开关配置
DEFAULT_SWITCHES = {
    # 开关系统
    "菜单": True,
    "休闲": True,
    "匿名": False,
    "点歌": True,
    "图片菜单": False,
    "图片模式": False,
    # 签到配置
    "签到": True,
    "发言自动签到": False,
    # 提醒系统
    "退群提示": True,
    "被踢提示": True,
    "上管提示": True,
    "下管提示": True,
    # 入群配置
    "入群欢迎": True,
    "入群奖励": False,
    "入群私聊": False,
    "入群扩列": False,
    # 邀请配置
    "邀请回复": False,
    "邀请奖励": False,
    "邀请扩列": False,
    # 扩展群管
    "防闪照": False,
    "防撤回": False,
    "复读机": False,
    "字数禁言": False,
    "字数撤回": False,
    "字数踢人": False,
    "字数禁言提示": False,
    "字数撤回提示": False,
    "字数踢人提示": False,
    # 银行系统
    "银行": True,
    "转账": True,
    "打劫": False,
    # 入群验证
    "入群验证": False,
    "发言验证": False,
    "加法验证": False,
    "静默验证": False,
    "入群验证码": False,
    "私聊验证码": False,
    # 入群审核
    "入群审核": False,
    "进群自动同意": False,
    "进群群内询问": False,
    "入群检测等级": False,
    "入群检测昵称": False,
    "入群检测签名": False,
    "黑名单禁止入群": True,
    # 榜单系统
    "榜单": True,
    # 广告杀手
    "撤回图片": False,
    "撤回表情": False,
    "撤回号码": False,
    "撤回链接": False,
    "撤回签到": False,
    "撤回回执": False,
    "撤回卡片": False,
    "撤回群链": False,
    "撤回匿名": False,
    "撤回语音": False,
    "撤回视频": False,
    "撤回转发": False,
    "撤回闪照": False,
    "撤回涂鸦": False,
    # 刷屏检测
    "刷屏检测": False,
    "刷屏禁言": False,
    "刷屏撤回": False,
    "刷屏踢出": False,
    "刷屏禁言提示": False,
    "刷屏撤回提示": False,
    "刷屏踢出提示": False,
    # 黑白名单
    "退群拉黑": False,
    "踢出拉黑": False,
    # 问答系统
    "问答": True,
    # 禁词系统
    "关键词禁言": False,
    "关键词撤回": False,
    "关键词踢人": False,
    "关键词禁言提示": False,
    "关键词撤回提示": False,
    "关键词踢人提示": False,
    # 拉黑配置
    "发言提示": False,
    "发言禁言": False,
    "发言踢出": False,
    "发言禁言提示": False,
    "发言踢出提示": False,
    # 超管命令
    "管理员模式": False,
}

# 默认数值配置
DEFAULT_VALUES = {
    # 签到配置
    "签到奖励": 10,
    "连签奖励": 5,
    # 入群配置
    "入群奖励积分": 100,
    # 邀请配置
    "邀请奖励积分": 50,
    # 扩展群管
    "禁言字数": 500,
    "撤回字数": 500,
    "踢人字数": 1000,
    "字数禁言时间": 10,
    # 银行系统
    "银行利润": 5,
    "银行利息": 10,
    # 入群验证
    "验证时间": 5,
    # 入群审核
    "入群等级": 1,
    # 刷屏检测
    "刷屏禁言时间": 10,
    "刷屏踢出机会": 3,
    # 禁词系统
    "禁词禁言时间": 10,
    "禁词踢人机会": 3,
    # 拉黑配置
    "发言提示间隔": 60,
    "发言禁言时间": 10,
}

# 默认文本配置
DEFAULT_TEXTS = {
    "入群欢迎": "欢迎 {nickname} 加入本群！",
    "入群私聊": "欢迎加入本群，请遵守群规！",
    "退群提示": "{nickname} 离开了我们...",
    "被踢提示": "{nickname} 被管理员请出了群聊",
    "上管提示": "恭喜 {nickname} 成为管理员！",
    "下管提示": "{nickname} 被取消了管理员身份",
    "邀请回复": "感谢 {inviter} 邀请 {nickname} 加入本群！",
    "发言提示内容": "你已被列入黑名单，请联系管理员",
    "禁言提示内容": "你已被禁言，原因：黑名单用户",
    "踢出提示内容": "你已被踢出群聊，原因：黑名单用户",
}

# 默认列表配置
DEFAULT_LISTS = {
    "群管列表": [],
    "黑名单": [],
    "白名单": [],
    "禁言词": [],
    "撤回词": [],
    "踢人词": [],
    "禁入昵称": [],
    "禁入签名": [],
    "指定撤回名单": [],
}


def get_default_group_config() -> Dict[str, Any]:
    """获取默认群配置"""
    return {
        "enabled": False,  # 默认未授权（关机状态）
        "switches": DEFAULT_SWITCHES.copy(),
        "values": DEFAULT_VALUES.copy(),
        "texts": DEFAULT_TEXTS.copy(),
        "lists": {k: v.copy() if isinstance(v, list) else v for k, v in DEFAULT_LISTS.items()},
        "authorization": {
            "expire_date": "",
            "super_admin_list": [],  # 超管列表（支持多个）
            "sync_admin_permission": False,  # 同步管理权限（开启后QQ群主/管理员自动获得超管权限）
        },
        "flood_rules": [],  # 刷屏检测规则
    }


class ConfigManager:
    """配置管理器"""

    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.config_file = data_dir / "config.json"
        self.users_file = data_dir / "users.json"
        self.qa_file = data_dir / "qa.json"
        self.stats_file = data_dir / "stats.json"
        self.global_file = data_dir / "global.json"  # 全局配置

        self._config: Dict[str, Dict] = {}
        self._users: Dict[str, Dict] = {}
        self._qa: Dict[str, Dict] = {}
        self._stats: Dict[str, Dict] = {}
        self._global: Dict[str, Any] = {}

        self._load_all()

    def _load_all(self):
        """加载所有配置"""
        self._config = self._load_json(self.config_file, {})
        self._users = self._load_json(self.users_file, {})
        self._qa = self._load_json(self.qa_file, {})
        self._stats = self._load_json(self.stats_file, {})
        self._global = self._load_json(self.global_file, DEFAULT_GLOBAL_CONFIG.copy())

    def _load_json(self, file: Path, default: Any) -> Any:
        """加载 JSON 文件"""
        if file.exists():
            try:
                with open(file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception:
                pass
        return default

    def _save_json(self, file: Path, data: Any):
        """保存 JSON 文件"""
        try:
            with open(file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            from loguru import logger
            logger.error(f"保存配置失败: {e}")

    def save_config(self):
        """保存群配置"""
        self._save_json(self.config_file, self._config)

    def save_users(self):
        """保存用户数据"""
        self._save_json(self.users_file, self._users)

    def save_qa(self):
        """保存问答词库"""
        self._save_json(self.qa_file, self._qa)

    def save_stats(self):
        """保存统计数据"""
        self._save_json(self.stats_file, self._stats)

    def save_global(self):
        """保存全局配置"""
        self._save_json(self.global_file, self._global)

    # 全局配置相关
    def get_owner_list(self) -> List[int]:
        """获取主人列表"""
        return self._global.get("owner_list", [])

    def add_owner(self, user_id: int):
        """添加主人"""
        if user_id not in self._global.get("owner_list", []):
            if "owner_list" not in self._global:
                self._global["owner_list"] = []
            self._global["owner_list"].append(user_id)
            self.save_global()

    def remove_owner(self, user_id: int):
        """删除主人"""
        if user_id in self._global.get("owner_list", []):
            self._global["owner_list"].remove(user_id)
            self.save_global()

    def is_owner(self, user_id: int) -> bool:
        """检查是否为主人"""
        return user_id in self._global.get("owner_list", [])

    def get_global_blacklist(self) -> List[int]:
        """获取全局黑名单"""
        return self._global.get("global_blacklist", [])

    def add_global_blacklist(self, user_id: int):
        """添加全局黑名单"""
        if user_id not in self._global.get("global_blacklist", []):
            if "global_blacklist" not in self._global:
                self._global["global_blacklist"] = []
            self._global["global_blacklist"].append(user_id)
            self.save_global()

    def remove_global_blacklist(self, user_id: int):
        """删除全局黑名单"""
        if user_id in self._global.get("global_blacklist", []):
            self._global["global_blacklist"].remove(user_id)
            self.save_global()

    def get_group_config(self, group_id: int) -> Dict[str, Any]:
        """获取群配置，不存在则创建默认配置"""
        gid = str(group_id)
        if gid not in self._config:
            self._config[gid] = get_default_group_config()
            self.save_config()
        return self._config[gid]

    def get_switch(self, group_id: int, name: str) -> bool:
        """获取开关状态"""
        config = self.get_group_config(group_id)
        return config["switches"].get(name, DEFAULT_SWITCHES.get(name, False))

    def set_switch(self, group_id: int, name: str, value: bool):
        """设置开关状态"""
        config = self.get_group_config(group_id)
        config["switches"][name] = value
        self.save_config()

    def get_value(self, group_id: int, name: str) -> int:
        """获取数值配置"""
        config = self.get_group_config(group_id)
        return config["values"].get(name, DEFAULT_VALUES.get(name, 0))

    def set_value(self, group_id: int, name: str, value: int):
        """设置数值配置"""
        config = self.get_group_config(group_id)
        config["values"][name] = value
        self.save_config()

    def get_text(self, group_id: int, name: str) -> str:
        """获取文本配置"""
        config = self.get_group_config(group_id)
        return config["texts"].get(name, DEFAULT_TEXTS.get(name, ""))

    def set_text(self, group_id: int, name: str, value: str):
        """设置文本配置"""
        config = self.get_group_config(group_id)
        config["texts"][name] = value
        self.save_config()

    def get_list(self, group_id: int, name: str) -> list:
        """获取列表配置"""
        config = self.get_group_config(group_id)
        return config["lists"].get(name, DEFAULT_LISTS.get(name, []))

    def add_to_list(self, group_id: int, name: str, item: Any):
        """添加到列表"""
        config = self.get_group_config(group_id)
        if name not in config["lists"]:
            config["lists"][name] = []
        if item not in config["lists"][name]:
            config["lists"][name].append(item)
            self.save_config()

    def remove_from_list(self, group_id: int, name: str, item: Any):
        """从列表移除"""
        config = self.get_group_config(group_id)
        if name in config["lists"] and item in config["lists"][name]:
            config["lists"][name].remove(item)
            self.save_config()

    def clear_list(self, group_id: int, name: str):
        """清空列表"""
        config = self.get_group_config(group_id)
        config["lists"][name] = []
        self.save_config()

    # 用户数据相关
    def get_user_data(self, group_id: int, user_id: int) -> Dict[str, Any]:
        """获取用户数据"""
        gid = str(group_id)
        uid = str(user_id)
        if gid not in self._users:
            self._users[gid] = {}
        if uid not in self._users[gid]:
            self._users[gid][uid] = {
                "nickname": "",
                "points": 0,
                "bank": 0,
                "loan": 0,
                "sign": {
                    "total_days": 0,
                    "continuous_days": 0,
                    "last_sign": "",
                },
                "stats": {
                    "messages": 0,
                    "invites": 0,
                },
            }
        return self._users[gid][uid]

    def set_user_data(self, group_id: int, user_id: int, data: Dict[str, Any]):
        """设置用户数据"""
        gid = str(group_id)
        uid = str(user_id)
        if gid not in self._users:
            self._users[gid] = {}
        self._users[gid][uid] = data
        self.save_users()

    def get_user_points(self, group_id: int, user_id: int) -> int:
        """获取用户积分"""
        return self.get_user_data(group_id, user_id).get("points", 0)

    def add_user_points(self, group_id: int, user_id: int, points: int):
        """增加用户积分"""
        data = self.get_user_data(group_id, user_id)
        data["points"] = data.get("points", 0) + points
        self.set_user_data(group_id, user_id, data)

    def get_all_users(self, group_id: int) -> Dict[str, Dict]:
        """获取群内所有用户数据"""
        gid = str(group_id)
        return self._users.get(gid, {})

    # 问答词库相关
    def get_qa(self, group_id: int) -> Dict[str, Dict]:
        """获取群问答词库"""
        gid = str(group_id)
        if gid not in self._qa:
            self._qa[gid] = {"精准": {}, "模糊": {}}
        return self._qa[gid]

    def add_qa(self, group_id: int, qa_type: str, question: str, answer: str):
        """添加问答"""
        qa = self.get_qa(group_id)
        if qa_type not in qa:
            qa[qa_type] = {}
        qa[qa_type][question] = answer
        self.save_qa()

    def remove_qa(self, group_id: int, qa_type: str, question: str):
        """删除问答"""
        qa = self.get_qa(group_id)
        if qa_type in qa and question in qa[qa_type]:
            del qa[qa_type][question]
            self.save_qa()

    def clear_qa(self, group_id: int, qa_type: str):
        """清空问答"""
        qa = self.get_qa(group_id)
        qa[qa_type] = {}
        self.save_qa()

    # 统计数据相关
    def get_stats(self, group_id: int) -> Dict[str, Any]:
        """获取群统计数据"""
        gid = str(group_id)
        if gid not in self._stats:
            self._stats[gid] = {
                "messages": {},  # {user_id: {date: count}}
                "invites": {},   # {user_id: [invited_user_ids]}
            }
        return self._stats[gid]

    def record_message(self, group_id: int, user_id: int):
        """记录发言"""
        stats = self.get_stats(group_id)
        uid = str(user_id)
        today = datetime.now().strftime("%Y-%m-%d")

        if uid not in stats["messages"]:
            stats["messages"][uid] = {}
        if today not in stats["messages"][uid]:
            stats["messages"][uid][today] = 0
        stats["messages"][uid][today] += 1
        self.save_stats()

    def record_invite(self, group_id: int, inviter_id: int, invited_id: int):
        """记录邀请"""
        stats = self.get_stats(group_id)
        uid = str(inviter_id)

        if uid not in stats["invites"]:
            stats["invites"][uid] = []
        if invited_id not in stats["invites"][uid]:
            stats["invites"][uid].append(invited_id)
            self.save_stats()

    # 授权相关
    def get_super_admin_list(self, group_id: int) -> List[int]:
        """获取超管列表"""
        config = self.get_group_config(group_id)
        auth = config.get("authorization", {})
        # 兼容旧版单个超管配置
        if "super_admin" in auth and auth["super_admin"]:
            old_admin = auth["super_admin"]
            if old_admin not in auth.get("super_admin_list", []):
                if "super_admin_list" not in auth:
                    auth["super_admin_list"] = []
                auth["super_admin_list"].append(old_admin)
                del auth["super_admin"]
                self.save_config()
        return auth.get("super_admin_list", [])

    def get_super_admin(self, group_id: int) -> int:
        """获取超管（兼容旧版，返回第一个超管）"""
        admin_list = self.get_super_admin_list(group_id)
        return admin_list[0] if admin_list else 0

    def add_super_admin(self, group_id: int, user_id: int):
        """添加超管"""
        config = self.get_group_config(group_id)
        if "super_admin_list" not in config["authorization"]:
            config["authorization"]["super_admin_list"] = []
        if user_id not in config["authorization"]["super_admin_list"]:
            config["authorization"]["super_admin_list"].append(user_id)
            self.save_config()

    def remove_super_admin(self, group_id: int, user_id: int):
        """删除超管"""
        config = self.get_group_config(group_id)
        if user_id in config["authorization"].get("super_admin_list", []):
            config["authorization"]["super_admin_list"].remove(user_id)
            self.save_config()

    def set_super_admin(self, group_id: int, user_id: int):
        """设置超管（兼容旧版，添加到列表）"""
        self.add_super_admin(group_id, user_id)

    def is_super_admin(self, group_id: int, user_id: int) -> bool:
        """检查是否为超管"""
        return user_id in self.get_super_admin_list(group_id)

    def get_expire_date(self, group_id: int) -> str:
        """获取授权到期日期"""
        config = self.get_group_config(group_id)
        return config["authorization"].get("expire_date", "")

    def set_expire_date(self, group_id: int, date: str):
        """设置授权到期日期"""
        config = self.get_group_config(group_id)
        config["authorization"]["expire_date"] = date
        self.save_config()

    def get_sync_admin_permission(self, group_id: int) -> bool:
        """获取是否同步管理权限"""
        config = self.get_group_config(group_id)
        return config["authorization"].get("sync_admin_permission", False)

    def set_sync_admin_permission(self, group_id: int, value: bool):
        """设置是否同步管理权限"""
        config = self.get_group_config(group_id)
        config["authorization"]["sync_admin_permission"] = value
        self.save_config()

    def is_group_enabled(self, group_id: int) -> bool:
        """检查群是否启用"""
        config = self.get_group_config(group_id)
        return config.get("enabled", True)

    def set_group_enabled(self, group_id: int, enabled: bool):
        """设置群启用状态"""
        config = self.get_group_config(group_id)
        config["enabled"] = enabled
        self.save_config()

    def is_authorized(self, group_id: int) -> bool:
        """检查是否已授权"""
        expire = self.get_expire_date(group_id)
        if not expire:
            return True  # 无授权限制
        try:
            expire_date = datetime.strptime(expire, "%Y-%m-%d")
            return datetime.now() <= expire_date
        except Exception:
            return True
