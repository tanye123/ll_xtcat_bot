"""
权限检查工具
"""
from typing import TYPE_CHECKING, List

if TYPE_CHECKING:
    from ..config import ConfigManager
    from core.event import MessageEvent

from ..config import FEATURE_PERMISSIONS


class PermissionChecker:
    """权限检查器"""

    def __init__(self, config: "ConfigManager", owner_id: int = 0):
        self.config = config
        self._legacy_owner_id = owner_id  # 兼容旧版单个主人配置

    def is_owner(self, user_id: int) -> bool:
        """是否为主人"""
        # 检查全局主人列表
        if self.config.is_owner(user_id):
            return True
        # 兼容旧版单个主人配置
        if self._legacy_owner_id and user_id == self._legacy_owner_id:
            return True
        return False

    def is_super_admin(self, group_id: int, user_id: int, event: "MessageEvent" = None) -> bool:
        """是否为超管"""
        if self.is_owner(user_id):
            return True
        # 检查超管列表
        if self.config.is_super_admin(group_id, user_id):
            return True
        # 如果开启了同步管理权限，QQ群主/管理员也视为超管
        if self.config.get_sync_admin_permission(group_id):
            if event and event.sender:
                role = event.sender.get("role", "member")
                if role in ("admin", "owner"):
                    return True
        return False

    def is_group_admin(self, group_id: int, user_id: int, event: "MessageEvent" = None) -> bool:
        """是否为群管（包括群管列表和 QQ 群管理员）"""
        if self.is_super_admin(group_id, user_id, event):
            return True

        # 检查群管列表
        admin_list = self.config.get_list(group_id, "群管列表")
        if user_id in admin_list:
            return True

        # 检查 QQ 群管理员/群主
        if event and event.sender:
            role = event.sender.get("role", "member")
            if role in ("admin", "owner"):
                return True

        return False

    def is_in_whitelist(self, group_id: int, user_id: int) -> bool:
        """是否在白名单"""
        whitelist = self.config.get_list(group_id, "白名单")
        return user_id in whitelist

    def is_in_blacklist(self, group_id: int, user_id: int) -> bool:
        """是否在黑名单"""
        # 检查全局黑名单
        if user_id in self.config.get_global_blacklist():
            return True
        # 检查群黑名单
        blacklist = self.config.get_list(group_id, "黑名单")
        return user_id in blacklist

    def check_permission(self, group_id: int, user_id: int, level: str, event: "MessageEvent" = None) -> bool:
        """
        检查权限

        Args:
            group_id: 群号
            user_id: 用户 QQ
            level: 权限级别 (all/admin/super/owner)
            event: 消息事件

        Returns:
            是否有权限
        """
        if level == "all":
            return True
        elif level == "admin":
            return self.is_group_admin(group_id, user_id, event)
        elif level == "super":
            return self.is_super_admin(group_id, user_id, event)
        elif level == "owner":
            return self.is_owner(user_id)
        return False

    def check_feature_permission(self, group_id: int, user_id: int, feature: str, event: "MessageEvent" = None) -> bool:
        """
        检查功能权限

        Args:
            group_id: 群号
            user_id: 用户 QQ
            feature: 功能名称
            event: 消息事件

        Returns:
            是否有权限使用该功能
        """
        level = FEATURE_PERMISSIONS.get(feature, "admin")  # 默认需要群管权限
        return self.check_permission(group_id, user_id, level, event)

    def get_permission_name(self, group_id: int, user_id: int, event: "MessageEvent" = None) -> str:
        """获取用户权限名称"""
        if self.is_owner(user_id):
            return "主人"
        if self.is_super_admin(group_id, user_id, event):
            return "超管"
        if self.is_group_admin(group_id, user_id, event):
            return "群管"
        return "成员"

    def get_owner_list(self) -> List[int]:
        """获取主人列表"""
        owners = self.config.get_owner_list()
        # 兼容旧版
        if self._legacy_owner_id and self._legacy_owner_id not in owners:
            owners = [self._legacy_owner_id] + owners
        return owners

    def get_super_admin_list(self, group_id: int) -> List[int]:
        """获取超管列表"""
        return self.config.get_super_admin_list(group_id)
