"""
消息格式化工具
"""
from typing import Any, Dict, List, Optional


class MessageFormatter:
    """消息格式化器"""

    @staticmethod
    def format_status(value: Any) -> str:
        """
        格式化状态显示

        Args:
            value: 状态值

        Returns:
            格式化后的状态字符串
        """
        if isinstance(value, bool):
            return "【【开】】" if value else "【【关】】"
        elif isinstance(value, (int, float)):
            return f"【【{value}】】"
        elif isinstance(value, str) and value:
            return "【【已设置】】"
        return ""

    @staticmethod
    def format_menu(title: str, permission: str, items: List[Dict[str, Any]]) -> str:
        """
        格式化菜单

        Args:
            title: 菜单标题
            permission: 权限说明
            items: 菜单项列表 [{"text": "xxx", "status": value}, ...]

        Returns:
            格式化后的菜单字符串
        """
        lines = [
            f"欢迎使用{title}",
            f"{permission}可用",
            "╭───────────╮",
        ]

        for item in items:
            text = item.get("text", "")
            status = item.get("status")
            status_str = MessageFormatter.format_status(status) if status is not None else ""
            lines.append(f"┣{text}{status_str}")

        lines.extend([
            "╰───────────╯",
            "到此结束",
        ])

        return "\n".join(lines)

    @staticmethod
    def format_main_menu() -> str:
        """格式化主菜单"""
        return """欢迎使用超级群管
◇━━整体功能━━◇
基础群管 扩展群管
入群审核 入群验证
广告杀手 撤回系统
黑白名单 拉黑配置
提醒系统 刷屏检测
入群配置 邀请配置
问答系统 榜单系统
禁词系统 银行系统
签到配置 休闲系统
统计系统 超管命令
主人命令 开关系统
◇━━━━━━━━━━◇
PS: 发相应文字查看
如：基础群管"""

    @staticmethod
    def format_list(title: str, items: List[Any], empty_msg: str = "列表为空") -> str:
        """
        格式化列表显示

        Args:
            title: 列表标题
            items: 列表项
            empty_msg: 空列表提示

        Returns:
            格式化后的列表字符串
        """
        if not items:
            return f"{title}\n{empty_msg}"

        lines = [title]
        for i, item in enumerate(items, 1):
            lines.append(f"{i}. {item}")

        return "\n".join(lines)

    @staticmethod
    def format_rank(title: str, data: List[Dict[str, Any]], key: str, unit: str = "") -> str:
        """
        格式化排行榜

        Args:
            title: 排行榜标题
            data: 排行数据
            key: 排序键
            unit: 单位

        Returns:
            格式化后的排行榜字符串
        """
        if not data:
            return f"{title}\n暂无数据"

        lines = [title, "╭───────────╮"]

        for i, item in enumerate(data[:10], 1):
            nickname = item.get("nickname", "未知")
            value = item.get(key, 0)
            lines.append(f"┣{i}. {nickname}: {value}{unit}")

        lines.append("╰───────────╯")

        return "\n".join(lines)

    @staticmethod
    def format_user_info(nickname: str, data: Dict[str, Any]) -> str:
        """
        格式化用户信息

        Args:
            nickname: 昵称
            data: 用户数据

        Returns:
            格式化后的用户信息字符串
        """
        points = data.get("points", 0)
        bank = data.get("bank", 0)
        loan = data.get("loan", 0)
        sign = data.get("sign", {})
        total_days = sign.get("total_days", 0)
        continuous_days = sign.get("continuous_days", 0)

        return f"""【{nickname}】的信息
╭───────────╮
┣积分: {points}
┣银行存款: {bank}
┣贷款: {loan}
┣累计签到: {total_days}天
┣连续签到: {continuous_days}天
╰───────────╯"""

    @staticmethod
    def replace_variables(text: str, variables: Dict[str, Any]) -> str:
        """
        替换文本中的变量

        Args:
            text: 原始文本
            variables: 变量字典

        Returns:
            替换后的文本
        """
        for key, value in variables.items():
            text = text.replace(f"{{{key}}}", str(value))
        return text

    @staticmethod
    def format_variables_help() -> str:
        """格式化变量帮助"""
        return """可用变量说明
╭───────────╮
┣{nickname} - 昵称
┣{user_id} - QQ号
┣{group_id} - 群号
┣{inviter} - 邀请人昵称
┣{date} - 日期
┣{time} - 时间
╰───────────╯"""
