"""
命令解析工具
"""
import re
from typing import Any, Dict, List, Optional, Tuple


class CommandParser:
    """命令解析器"""

    @staticmethod
    def parse_switch(text: str, switch_names: List[str]) -> Optional[Tuple[str, bool]]:
        """
        解析开关命令

        Args:
            text: 消息文本
            switch_names: 开关名称列表

        Returns:
            (开关名, 开/关) 或 None
        """
        text = text.strip()

        # 匹配 "xxx开" 或 "xxx关"
        for name in switch_names:
            if text == f"{name}开":
                return (name, True)
            elif text == f"{name}关":
                return (name, False)

        return None

    @staticmethod
    def parse_value(text: str, value_names: List[str]) -> Optional[Tuple[str, int]]:
        """
        解析数值命令

        Args:
            text: 消息文本
            value_names: 数值配置名称列表

        Returns:
            (配置名, 数值) 或 None
        """
        text = text.strip()

        for name in value_names:
            # 匹配 "xxx 数值" 或 "xxx数值"
            pattern = rf"^{re.escape(name)}\s*(\d+)$"
            match = re.match(pattern, text)
            if match:
                return (name, int(match.group(1)))

        return None

    @staticmethod
    def parse_text(text: str, text_names: List[str]) -> Optional[Tuple[str, str]]:
        """
        解析文本命令

        Args:
            text: 消息文本
            text_names: 文本配置名称列表

        Returns:
            (配置名, 内容) 或 None
        """
        text = text.strip()

        for name in text_names:
            # 匹配 "xxx 内容"
            if text.startswith(name + " "):
                content = text[len(name) + 1:].strip()
                if content:
                    return (name, content)

        return None

    @staticmethod
    def parse_at(text: str) -> List[int]:
        """
        解析 @ 的用户

        Args:
            text: 消息文本

        Returns:
            被 @ 的用户 QQ 列表
        """
        # 匹配 [CQ:at,qq=xxx] 或 [CQ:at,qq=xxx,name=xxx] 等格式
        pattern = r"\[CQ:at,qq=(\d+)[^\]]*\]"
        matches = re.findall(pattern, text)
        return [int(qq) for qq in matches]

    @staticmethod
    def parse_action_at(text: str, actions: List[str]) -> Optional[Tuple[str, List[int], Optional[int]]]:
        """
        解析操作命令（带 @）

        Args:
            text: 消息文本
            actions: 动作名称列表

        Returns:
            (动作名, 目标用户列表, 可选参数) 或 None
        """
        text = text.strip()

        for action in actions:
            if text.startswith(action):
                rest = text[len(action):].strip()

                # 提取 @ 的用户
                targets = CommandParser.parse_at(rest)

                # 移除 @ 部分，提取数值参数
                rest_clean = re.sub(r"\[CQ:at,qq=\d+[^\]]*\]", "", rest).strip()

                param = None
                if rest_clean:
                    try:
                        param = int(rest_clean)
                    except ValueError:
                        pass

                if targets:
                    return (action, targets, param)

        return None

    @staticmethod
    def parse_action_qq(text: str, actions: List[str]) -> Optional[Tuple[str, int, Optional[str]]]:
        """
        解析操作命令（带 QQ 号）

        Args:
            text: 消息文本
            actions: 动作名称列表

        Returns:
            (动作名, QQ号, 可选参数) 或 None
        """
        text = text.strip()

        for action in actions:
            if text.startswith(action + " "):
                rest = text[len(action) + 1:].strip()

                # 匹配 QQ 号
                match = re.match(r"^(\d{5,12})(?:\s+(.+))?$", rest)
                if match:
                    qq = int(match.group(1))
                    param = match.group(2)
                    return (action, qq, param)

        return None

    @staticmethod
    def parse_list_action(text: str, list_names: List[str]) -> Optional[Tuple[str, str, Optional[Any]]]:
        """
        解析列表操作命令

        Args:
            text: 消息文本
            list_names: 列表名称

        Returns:
            (操作, 列表名, 内容) 或 None
        """
        text = text.strip()

        for name in list_names:
            # 加xxx 内容
            if text.startswith(f"加{name} "):
                content = text[len(f"加{name} "):].strip()
                return ("add", name, content)

            # 删xxx 内容
            if text.startswith(f"删{name} "):
                content = text[len(f"删{name} "):].strip()
                return ("remove", name, content)

            # 查看xxx列表
            if text == f"查看{name}列表":
                return ("view", name, None)

            # 清空xxx列表
            if text == f"清空{name}列表":
                return ("clear", name, None)

        return None

    @staticmethod
    def parse_qa(text: str) -> Optional[Tuple[str, str, str, bool]]:
        """
        解析问答命令

        Args:
            text: 消息文本

        Returns:
            (类型, 问题, 回答, 是否私聊) 或 None
        """
        text = text.strip()

        # 精准问xxx答xxx / 模糊问xxx答xxx
        for qa_type in ["精准", "模糊"]:
            # 公开回复
            pattern = rf"^{qa_type}问(.+)答(.+)$"
            match = re.match(pattern, text)
            if match:
                return (qa_type, match.group(1), match.group(2), False)

            # 私聊回复
            pattern = rf"^{qa_type}问(.+)私(.+)$"
            match = re.match(pattern, text)
            if match:
                return (qa_type, match.group(1), match.group(2), True)

        # 删精准/模糊 xxx
        for qa_type in ["精准", "模糊"]:
            if text.startswith(f"删{qa_type} "):
                question = text[len(f"删{qa_type} "):].strip()
                return (qa_type, question, "", False)

        return None

    @staticmethod
    def clean_cq_code(text: str) -> str:
        """移除 CQ 码，保留纯文本"""
        return re.sub(r"\[CQ:[^\]]+\]", "", text).strip()
