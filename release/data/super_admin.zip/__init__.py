"""
超级群管插件
"""
from datetime import datetime
from typing import Optional
from loguru import logger

from core import Plugin, on_message, on_notice, on_request, MessageEvent, NoticeEvent, RequestEvent

from .config import ConfigManager
from .utils.permission import PermissionChecker
from .handlers.menu import MenuHandler
from .handlers.switch import SwitchHandler
from .handlers.leisure import LeisureHandler
from .handlers.sign import SignHandler
from .handlers.stats import StatsHandler
from .handlers.admin import AdminHandler
from .handlers.notify import NotifyHandler
from .handlers.basic import BasicHandler
from .handlers.join import JoinHandler
from .handlers.extend import ExtendHandler
from .handlers.recall import RecallHandler
from .handlers.bank import BankHandler
from .handlers.verify import VerifyHandler
from .handlers.rank import RankHandler
from .handlers.antiad import AntiAdHandler
from .handlers.antiflood import AntiFloodHandler
from .handlers.blacklist import BlacklistHandler
from .handlers.qa import QAHandler
from .handlers.keyword import KeywordHandler


class SuperAdminPlugin(Plugin):
    """超级群管插件"""

    name = "超级群管"
    description = "功能强大的群管理插件，支持菜单系统、签到、银行、问答等多种功能"
    version = "1.0.0"
    author = "LL_XTCAT"

    # 主人 QQ 号（可在配置中修改）
    OWNER_ID = 0

    def __init__(self, bot, plugin_dir=None):
        """初始化插件"""
        super().__init__(bot, plugin_dir)

        logger.info(f"初始化插件: {self.name} v{self.version}")

        # 初始化配置管理器
        self.config_manager = ConfigManager(self.data_dir)

        # 初始化权限检查器
        self.permission = PermissionChecker(self.config_manager, self.OWNER_ID)

        # 初始化各处理器
        self.menu_handler = MenuHandler(self.config_manager, self.permission)
        self.switch_handler = SwitchHandler(self.config_manager, self.permission)
        self.leisure_handler = LeisureHandler(self.config_manager, self.permission)
        self.sign_handler = SignHandler(self.config_manager, self.permission)
        self.stats_handler = StatsHandler(self.config_manager, self.permission)
        self.admin_handler = AdminHandler(self.config_manager, self.permission)
        self.notify_handler = NotifyHandler(self.config_manager, self.permission)
        self.basic_handler = BasicHandler(self.config_manager, self.permission)
        self.join_handler = JoinHandler(self.config_manager, self.permission)
        self.extend_handler = ExtendHandler(self.config_manager, self.permission)
        self.recall_handler = RecallHandler(self.config_manager, self.permission)
        self.bank_handler = BankHandler(self.config_manager, self.permission)
        self.verify_handler = VerifyHandler(self.config_manager, self.permission)
        self.rank_handler = RankHandler(self.config_manager, self.permission)
        self.antiad_handler = AntiAdHandler(self.config_manager, self.permission)
        self.antiflood_handler = AntiFloodHandler(self.config_manager, self.permission)
        self.blacklist_handler = BlacklistHandler(self.config_manager, self.permission)
        self.qa_handler = QAHandler(self.config_manager, self.permission)
        self.keyword_handler = KeywordHandler(self.config_manager, self.permission)

    async def on_load(self):
        """插件加载时调用（框架当前未调用此方法）"""
        pass

    async def on_unload(self):
        """插件卸载"""
        logger.info(f"卸载插件: {self.name}")

    @on_message(message_type="group")
    async def handle_group_message(self, event: MessageEvent):
        """处理群消息"""
        group_id = event.group_id
        user_id = event.user_id
        text = event.raw_message
        message_id = event.message_id
        nickname = event.sender.get("nickname", str(user_id))

        # 检查群是否启用
        config = self.config_manager.get_group_config(group_id)
        if not config.get("enabled", True):
            # 只响应开机命令
            if text.strip() == "开机" and self.permission.is_group_admin(group_id, user_id, event):
                config["enabled"] = True
                self.config_manager.save_config()
                await self.bot.api.send_group_msg(group_id, "机器人已开机")
            return

        # 记录发言统计
        self.stats_handler.record_message(group_id, user_id, nickname)

        # 检查是否在验证中
        if self.verify_handler.is_pending_verify(group_id, user_id):
            result = self.verify_handler.check_verify(group_id, user_id, text)
            if result == "success":
                await self.bot.api.send_group_msg(group_id, f"验证成功！欢迎 {nickname}")
                return
            elif result == "timeout":
                await self.bot.api.set_group_kick(group_id, user_id, False)
                return

        # 自动撤回检查
        await self.recall_handler.check_auto_recall(group_id, user_id, message_id, self.bot.api)

        # 广告杀手检查
        ad_result = await self.antiad_handler.check_message(group_id, user_id, text, message_id, self.bot.api)
        if ad_result:
            return

        # 刷屏检测
        flood_result = await self.antiflood_handler.check_flood(group_id, user_id, message_id, self.bot.api)
        if flood_result:
            await self.bot.api.send_group_msg(group_id, flood_result)
            return

        # 禁词检测
        keyword_result = await self.keyword_handler.check_keyword(group_id, user_id, text, message_id, self.bot.api)
        if keyword_result:
            await self.bot.api.send_group_msg(group_id, keyword_result)
            return

        # 字数检测
        extend_result = await self.extend_handler.check_message_length(group_id, user_id, text, message_id, self.bot.api)
        if extend_result:
            await self.bot.api.send_group_msg(group_id, extend_result)
            return

        # 问答系统检查
        qa_result = self.qa_handler.check_qa(group_id, text)
        if qa_result:
            if qa_result["private"]:
                await self.bot.api.send_private_msg(user_id, qa_result["answer"])
            else:
                await self.bot.api.send_group_msg(group_id, qa_result["answer"])
            return

        # 菜单系统
        if self.menu_handler.is_menu_command(text):
            result = self.menu_handler.handle(group_id, user_id, text, event)
            if result:
                await self.bot.api.send_group_msg(group_id, result)
            return

        # 开关系统
        switch_result = self.switch_handler.handle(group_id, user_id, text, event)
        if switch_result:
            await self.bot.api.send_group_msg(group_id, switch_result)
            return

        # 休闲系统
        if self.leisure_handler.is_leisure_command(text):
            result = await self.leisure_handler.handle(group_id, user_id, text, event)
            if result:
                if result["type"] == "text":
                    await self.bot.api.send_group_msg(group_id, result["content"])
                elif result["type"] == "image":
                    msg = [{"type": "image", "data": {"file": result["url"]}}]
                    await self.bot.api.send_group_msg(group_id, msg)
            return

        # 签到系统
        if self.sign_handler.is_sign_command(text):
            result = self.sign_handler.handle(group_id, user_id, text, nickname, event)
            if result:
                await self.bot.api.send_group_msg(group_id, result)
            return

        # 签到配置
        sign_config_result = self.sign_handler.handle_config(group_id, user_id, text, event)
        if sign_config_result:
            await self.bot.api.send_group_msg(group_id, sign_config_result)
            return

        # 统计系统
        stats_result = self.stats_handler.handle(group_id, user_id, text, event)
        if stats_result:
            await self.bot.api.send_group_msg(group_id, stats_result)
            return

        # 超管/主人命令
        admin_result = self.admin_handler.handle(group_id, user_id, text, event)
        if admin_result:
            await self.bot.api.send_group_msg(group_id, admin_result)
            return

        # 提醒系统配置
        notify_result = self.notify_handler.handle(group_id, user_id, text, event)
        if notify_result:
            await self.bot.api.send_group_msg(group_id, notify_result)
            return

        # 基础群管
        basic_result = await self.basic_handler.handle(group_id, user_id, text, self.bot.api, event)
        if basic_result:
            await self.bot.api.send_group_msg(group_id, basic_result)
            return

        # 入群/邀请配置
        join_result = self.join_handler.handle(group_id, user_id, text, event)
        if join_result:
            await self.bot.api.send_group_msg(group_id, join_result)
            return

        # 扩展群管配置
        extend_config_result = self.extend_handler.handle(group_id, user_id, text, event)
        if extend_config_result:
            await self.bot.api.send_group_msg(group_id, extend_config_result)
            return

        # 撤回系统
        recall_result = await self.recall_handler.handle(group_id, user_id, text, self.bot.api, event)
        if recall_result:
            await self.bot.api.send_group_msg(group_id, recall_result)
            return

        # 银行系统
        bank_result = self.bank_handler.handle(group_id, user_id, text, nickname, event)
        if bank_result:
            await self.bot.api.send_group_msg(group_id, bank_result)
            return

        # 入群验证/审核配置
        verify_result = self.verify_handler.handle(group_id, user_id, text, event)
        if verify_result:
            await self.bot.api.send_group_msg(group_id, verify_result)
            return

        # 榜单系统
        rank_result = self.rank_handler.handle(group_id, user_id, text, event)
        if rank_result:
            await self.bot.api.send_group_msg(group_id, rank_result)
            return

        # 刷屏检测配置
        antiflood_result = self.antiflood_handler.handle(group_id, user_id, text, event)
        if antiflood_result:
            await self.bot.api.send_group_msg(group_id, antiflood_result)
            return

        # 黑白名单
        blacklist_result = self.blacklist_handler.handle(group_id, user_id, text, event)
        if blacklist_result:
            await self.bot.api.send_group_msg(group_id, blacklist_result)
            return

        # 问答系统配置
        qa_config_result = self.qa_handler.handle(group_id, user_id, text, event)
        if qa_config_result:
            await self.bot.api.send_group_msg(group_id, qa_config_result)
            return

        # 禁词系统配置
        keyword_config_result = self.keyword_handler.handle(group_id, user_id, text, event)
        if keyword_config_result:
            await self.bot.api.send_group_msg(group_id, keyword_config_result)
            return

    @on_notice(notice_type="group_increase")
    async def handle_group_increase(self, event: NoticeEvent):
        """处理入群事件"""
        group_id = event.group_id
        user_id = event.user_id
        operator_id = event.raw_data.get("operator_id", 0)

        # 获取用户信息
        user_info = await self.bot.api.get_group_member_info(group_id, user_id)
        nickname = user_info.get("nickname", str(user_id))

        variables = {
            "nickname": nickname,
            "user_id": user_id,
            "group_id": group_id,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%H:%M:%S"),
        }

        # 入群验证
        verify_msg = self.verify_handler.start_verify(group_id, user_id)
        if verify_msg:
            await self.bot.api.send_group_msg(group_id, verify_msg)
            return

        # 入群欢迎
        welcome_msg = self.join_handler.get_welcome_message(group_id, variables)
        if welcome_msg:
            await self.bot.api.send_group_msg(group_id, welcome_msg)

        # 入群私聊
        private_msg = self.join_handler.get_private_message(group_id, variables)
        if private_msg:
            await self.bot.api.send_private_msg(user_id, private_msg)

        # 入群奖励
        reward = self.join_handler.get_join_reward(group_id)
        if reward > 0:
            self.config_manager.add_user_points(group_id, user_id, reward)

        # 邀请奖励
        if operator_id and operator_id != user_id:
            # 记录邀请
            self.stats_handler.record_invite(group_id, operator_id, user_id)

            # 邀请奖励
            invite_reward = self.join_handler.get_invite_reward(group_id)
            if invite_reward > 0:
                self.config_manager.add_user_points(group_id, operator_id, invite_reward)

            # 邀请回复
            inviter_info = await self.bot.api.get_group_member_info(group_id, operator_id)
            inviter_name = inviter_info.get("nickname", str(operator_id))
            variables["inviter"] = inviter_name

            invite_msg = self.join_handler.get_invite_message(group_id, variables)
            if invite_msg:
                await self.bot.api.send_group_msg(group_id, invite_msg)

    @on_notice(notice_type="group_decrease")
    async def handle_group_decrease(self, event: NoticeEvent):
        """处理退群事件"""
        group_id = event.group_id
        user_id = event.user_id
        operator_id = event.raw_data.get("operator_id", 0)
        sub_type = event.raw_data.get("sub_type", "leave")

        # 获取用户信息（可能获取不到）
        nickname = str(user_id)

        variables = {
            "nickname": nickname,
            "user_id": user_id,
            "group_id": group_id,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%H:%M:%S"),
        }

        if sub_type == "kick":
            # 被踢提示
            msg = self.notify_handler.get_notify_message(group_id, "被踢提示", variables)
            if msg:
                await self.bot.api.send_group_msg(group_id, msg)

            # 踢出拉黑
            if self.config_manager.get_switch(group_id, "踢出拉黑"):
                self.config_manager.add_to_list(group_id, "黑名单", user_id)
        else:
            # 退群提示
            msg = self.notify_handler.get_notify_message(group_id, "退群提示", variables)
            if msg:
                await self.bot.api.send_group_msg(group_id, msg)

            # 退群拉黑
            if self.config_manager.get_switch(group_id, "退群拉黑"):
                self.config_manager.add_to_list(group_id, "黑名单", user_id)

    @on_notice(notice_type="group_admin")
    async def handle_group_admin(self, event: NoticeEvent):
        """处理管理员变动事件"""
        group_id = event.group_id
        user_id = event.user_id
        sub_type = event.raw_data.get("sub_type", "")

        # 获取用户信息
        user_info = await self.bot.api.get_group_member_info(group_id, user_id)
        nickname = user_info.get("nickname", str(user_id))

        variables = {
            "nickname": nickname,
            "user_id": user_id,
            "group_id": group_id,
            "date": datetime.now().strftime("%Y-%m-%d"),
            "time": datetime.now().strftime("%H:%M:%S"),
        }

        if sub_type == "set":
            # 上管提示
            msg = self.notify_handler.get_notify_message(group_id, "上管提示", variables)
            if msg:
                await self.bot.api.send_group_msg(group_id, msg)
        elif sub_type == "unset":
            # 下管提示
            msg = self.notify_handler.get_notify_message(group_id, "下管提示", variables)
            if msg:
                await self.bot.api.send_group_msg(group_id, msg)

    @on_request(request_type="group")
    async def handle_group_request(self, event: RequestEvent):
        """处理入群请求"""
        group_id = event.group_id
        user_id = event.user_id
        comment = event.comment
        flag = event.flag
        sub_type = event.sub_type

        if sub_type != "add":
            return

        # 检查入群请求
        approve, reason = await self.verify_handler.check_join_request(
            group_id, user_id, comment, self.bot.api
        )

        if approve is True:
            await self.bot.api.set_group_add_request(flag, sub_type, True)
        elif approve is False:
            await self.bot.api.set_group_add_request(flag, sub_type, False, reason)
        # approve is None 表示需要人工审核，不自动处理

    @on_notice(notice_type="group_recall")
    async def handle_group_recall(self, event: NoticeEvent):
        """处理消息撤回事件（防撤回）"""
        group_id = event.group_id
        user_id = event.user_id
        operator_id = event.raw_data.get("operator_id", user_id)
        message_id = event.raw_data.get("message_id")

        # 检查防撤回开关
        if not self.config_manager.get_switch(group_id, "防撤回"):
            return

        # 不处理机器人自己的撤回
        if user_id == self.bot.self_id:
            return

        # 获取被撤回的消息
        try:
            msg_data = await self.bot.api.get_msg(message_id)
            if not msg_data:
                return

            # 获取撤回者信息
            user_info = await self.bot.api.get_group_member_info(group_id, user_id)
            nickname = user_info.get("nickname", str(user_id))

            # 获取消息内容
            message = msg_data.get("message", "")
            raw_message = msg_data.get("raw_message", "")

            # 构建防撤回提示
            if operator_id != user_id:
                # 管理员撤回别人的消息
                operator_info = await self.bot.api.get_group_member_info(group_id, operator_id)
                operator_name = operator_info.get("nickname", str(operator_id))
                tip = f"【防撤回】{operator_name} 撤回了 {nickname} 的消息:\n{raw_message}"
            else:
                tip = f"【防撤回】{nickname} 撤回了一条消息:\n{raw_message}"

            await self.bot.api.send_group_msg(group_id, tip)

        except Exception as e:
            logger.debug(f"防撤回获取消息失败: {e}")
